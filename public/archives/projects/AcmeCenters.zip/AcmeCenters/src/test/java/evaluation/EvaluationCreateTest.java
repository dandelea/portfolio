package evaluation;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.util.Assert;

import security.LoginService;
import services.EvaluationService;
import services.NotificationService;
import services.StudentService;
import services.SubjectService;
import utilities.PopulateDatabase;
import domain.Evaluation;
import domain.Student;
import domain.Subject;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class EvaluationCreateTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private EvaluationService evaluationService;

	@Autowired
	private StudentService studentService;

	@Autowired
	private SubjectService subjectService;

	@Autowired
	private NotificationService notificationService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test()
	public void createOptionalEvaluation() {
		authenticate("professor1");
		Subject subject = subjectService.findOne(15);
		Evaluation evaluation = evaluationService.create(subject);
		evaluation.setName("name");
		evaluation.setDescription("description");
		evaluation.setDeliverablesDescription("deliverablesDescription");
		evaluation
				.setFinishDate(new Date(System.currentTimeMillis() + 1000000));
		evaluation.setObligatory(false);
		evaluation = evaluationService.save(evaluation);
		Assert.notNull(evaluation);
		Assert.isTrue(evaluation.getId() != 0);

		authenticate("student1");
		Student student = studentService.findByPrincipal();
		Assert.isTrue(notificationService.findByStudent(student).size() == 3);
	}

	@Test()
	public void createObligatoryEvaluation() {
		authenticate("professor1");
		Subject subject = subjectService.findOne(15);
		Evaluation evaluation = evaluationService.create(subject);
		evaluation.setName("name");
		evaluation.setDescription("description");
		evaluation.setDeliverablesDescription("deliverablesDescription");
		evaluation
				.setFinishDate(new Date(System.currentTimeMillis() + 1000000));
		evaluation.setObligatory(true);
		evaluation = evaluationService.save(evaluation);
		Assert.notNull(evaluation);
		Assert.isTrue(evaluation.getId() != 0);

		authenticate("student1");
		Student student = studentService.findByPrincipal();
		Assert.isTrue(notificationService.findByStudent(student).size() == 3);

		Assert.isTrue(evaluationService.findRegisteredNotFinished().size() == 1);
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeCreateOptionalEvaluation_WrongPrincipal() {
		authenticate("professor1");
		Subject subject = subjectService.findOne(15);
		Evaluation evaluation = evaluationService.create(subject);
		evaluation.setName("name");
		evaluation.setDescription("description");
		evaluation.setDeliverablesDescription("deliverablesDescription");
		evaluation
				.setFinishDate(new Date(System.currentTimeMillis() + 1000000));
		evaluation.setObligatory(false);

		authenticate("professor2");

		evaluationService.save(evaluation);
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeCreateOptionalEvaluation_StillOpenSubject() {
		authenticate("professor1");
		Subject subject = subjectService.findOne(16);
		Evaluation evaluation = evaluationService.create(subject);
		evaluation.setName("name");
		evaluation.setDescription("description");
		evaluation.setDeliverablesDescription("deliverablesDescription");
		evaluation
				.setFinishDate(new Date(System.currentTimeMillis() + 1000000));
		evaluation.setObligatory(false);

		evaluationService.save(evaluation);
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeCreateOptionalEvaluation_NullSubject() {
		authenticate("professor1");
		Evaluation evaluation = evaluationService.create(null);
		evaluation.setName("name");
		evaluation.setDescription("description");
		evaluation.setDeliverablesDescription("deliverablesDescription");
		evaluation
				.setFinishDate(new Date(System.currentTimeMillis() + 1000000));
		evaluation.setObligatory(false);

		evaluationService.save(evaluation);
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeCreateOptionalEvaluation_BlankName() {
		authenticate("professor1");
		Subject subject = subjectService.findOne(15);
		Evaluation evaluation = evaluationService.create(subject);
		evaluation.setName("");
		evaluation.setDescription("description");
		evaluation.setDeliverablesDescription("deliverablesDescription");
		evaluation
				.setFinishDate(new Date(System.currentTimeMillis() + 1000000));
		evaluation.setObligatory(false);

		evaluationService.save(evaluation);
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeCreateOptionalEvaluation_NullName() {
		authenticate("professor1");
		Subject subject = subjectService.findOne(15);
		Evaluation evaluation = evaluationService.create(subject);
		evaluation.setDescription("description");
		evaluation.setDeliverablesDescription("deliverablesDescription");
		evaluation
				.setFinishDate(new Date(System.currentTimeMillis() + 1000000));
		evaluation.setObligatory(false);

		evaluationService.save(evaluation);
	}

}
