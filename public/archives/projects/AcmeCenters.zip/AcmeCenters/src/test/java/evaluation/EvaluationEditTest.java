package evaluation;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.util.Assert;

import security.LoginService;
import services.EvaluationService;
import utilities.PopulateDatabase;
import domain.Evaluation;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class EvaluationEditTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private EvaluationService evaluationService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test()
	public void editEvaluation() {
		authenticate("professor2");
		Evaluation evaluation = evaluationService.findOne(31);
		evaluation.setName("editedName");
		evaluation = evaluationService.save(evaluation);

		Assert.isTrue(evaluation.getName().equals("editedName"));
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeEditEvaluation_WrongPrincipal() {
		authenticate("professor1");
		Evaluation evaluation = evaluationService.findOne(31);
		evaluation.setName("editedName");
		evaluationService.save(evaluation);
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeEditEvaluation_EvaluationWithStudents() {
		authenticate("professor2");
		Evaluation evaluation = evaluationService.findOne(29);
		evaluation.setName("editedName");
		evaluationService.save(evaluation);
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeEditEvaluation_FinishedEvaluation() {
		authenticate("professor2");
		Evaluation evaluation = evaluationService.findOne(33);
		evaluation.setName("editedName");
		evaluationService.save(evaluation);
	}

	@Test(expected = NullPointerException.class)
	public void negativeEditEvaluation_NullSubject() {
		authenticate("professor2");
		Evaluation evaluation = evaluationService.findOne(31);
		evaluation.setSubject(null);
		evaluationService.save(evaluation);
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeEditEvaluation_BlankName() {
		authenticate("professor2");
		Evaluation evaluation = evaluationService.findOne(31);
		evaluation.setName("");
		evaluationService.save(evaluation);
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeEditEvaluation_NullName() {
		authenticate("professor2");
		Evaluation evaluation = evaluationService.findOne(31);
		evaluation.setName(null);
		evaluationService.save(evaluation);
	}

}
