package student;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.util.Assert;

import security.LoginService;
import services.StudentService;
import utilities.PopulateDatabase;
import domain.Student;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class StudentEditionTest {
	@Autowired
	private LoginService loginService;

	@Autowired
	private StudentService studentService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test
	public void editProfile() {
		System.out.println("Editar el perfil");
		authenticate("student1");
		Student student = studentService.findOne(9);
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_EditProfile_Name_Blank() {
		System.out.println("Editar el perfil con nombre vacio");
		authenticate("student1");
		Student student = studentService.findOne(9);
		student.setName("");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_EditProfile_Surname_Blank() {
		System.out.println("Editar el perfil con apellido vacio");
		authenticate("student1");
		Student student = studentService.findOne(9);
		student.setName("Name");
		student.setSurname("");
		student.setEmail("email@mail.com");
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_EditProfile_Email_Blank() {
		System.out.println("Editar el perfil con email vacio");
		authenticate("student1");
		Student student = studentService.findOne(9);
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("");
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_EditProfile_Email_WrongPattern() {
		System.out.println("Editar el perfil con email incorrecto");
		authenticate("student1");
		Student student = studentService.findOne(9);
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email");
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_EditProfile_Phone_Blank() {
		System.out.println("Editar el perfil con n�mero de tel�fono vacio");
		authenticate("student1");
		Student student = studentService.findOne(9);
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		student.setPhone("");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_EditProfile_Phone_WrongPattern() {
		System.out.println("Editar el perfil con n�mero de tel�fono vacio");
		authenticate("student1");
		Student student = studentService.findOne(9);
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		student.setPhone("123");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_EditProfile_NameAndSurnamesFather_Blank() {
		System.out.println("Editar el perfil con nombre/apellidos padre vacio");
		authenticate("student1");
		Student student = studentService.findOne(9);
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_EditProfile_NameAndSurnamesMother_Blank() {
		System.out.println("Editar el perfil con nombre/apellidos madre vacio");
		authenticate("student1");
		Student student = studentService.findOne(9);
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_EditProfile_Interests_Blank() {
		System.out.println("Editar el perfil con intereses vacio");
		authenticate("student1");
		Student student = studentService.findOne(9);
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_EditProfile_Address_Blank() {
		System.out.println("Editar el perfil con direccion vacio");
		authenticate("student1");
		Student student = studentService.findOne(9);
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeTest_EditProfile_NotPrincipal() {
		System.out.println("Editar el perfil por otro estudiante");
		authenticate("student2");
		Student student = studentService.findOne(9);
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeTest_EditProfile_NotProfessor() {
		System.out.println("Editar el perfil por un profesor no autorizado");
		authenticate("professor3");
		Student student = studentService.findOne(9);
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		Assert.notNull(studentService.save(student));
	}
}