package centers;

import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import security.LoginService;
import services.CenterService;
import utilities.PopulateDatabase;
import domain.Center;
import forms.CenterSearchForm;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class CentersListTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private CenterService centerService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test
	public void listCenters() {
		Collection<Center> centers = centerService.findAll();
		Integer tam = centers.size();
		Assert.isTrue(tam.equals(2));
	}

	@Test
	public void listCentersByStudent() {
		authenticate("student1");
		Collection<Center> centers = centerService.findByPrincipalStudent();
		Integer tam = centers.size();
		Assert.isTrue(tam.equals(2));
	}

	@Test
	public void listCentersByProfessor() {
		authenticate("professor1");
		Collection<Center> centers = centerService.findByPrincipal();
		Integer tam = centers.size();
		Assert.isTrue(tam.equals(1));
	}

	@Test
	public void listCentersBySearch() {
		CenterSearchForm centerSearchForm = new CenterSearchForm();
		centerSearchForm.setCode("code");
		centerSearchForm.setAddress("");
		centerSearchForm.setDescription("");
		centerSearchForm.setName("");
		centerSearchForm.setPostalCode("");
		centerSearchForm.setDependency(null);
		centerSearchForm.setRadius(null);
		centerSearchForm.setLatitude(0.0);
		centerSearchForm.setLongitude(0.0);
		Collection<Center> centers = centerService.search(centerSearchForm);
		Integer tam = centers.size();
		Assert.isTrue(tam.equals(2));
	}

	@Test(expected = IllegalArgumentException.class)
	public void listCentersByStudent_BadAutehtication() {
		authenticate("professor1");
		Collection<Center> centers = centerService.findByPrincipalStudent();
		Integer tam = centers.size();
		Assert.isTrue(tam.equals(2));
	}

	@Test(expected = IllegalArgumentException.class)
	public void listCentersByProfessor_BadAuthentication() {
		authenticate("student2");
		Collection<Center> centers = centerService.findByPrincipal();
		Integer tam = centers.size();
		Assert.isTrue(tam.equals(1));
	}
}
