package evaluation;

import javax.validation.ConstraintViolationException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import security.LoginService;
import services.EvaluatedStudentService;
import services.NotificationService;
import services.StudentService;
import utilities.PopulateDatabase;
import domain.EvaluatedStudent;
import domain.Student;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class EvaluatedStudentEditTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private EvaluatedStudentService evaluatedStudentService;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private StudentService studentService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test()
	public void editEvaluatedStudentAddMark() {
		authenticate("professor1");
		EvaluatedStudent evaluatedStudent = evaluatedStudentService.findOne(35);
		evaluatedStudent.setMark(10.0);
		evaluatedStudent = evaluatedStudentService.save(evaluatedStudent);
		Assert.isTrue(evaluatedStudent.getRegistration().getFinalMark()
				.equals(10.0));

		authenticate("student1");
		Student student = studentService.findByPrincipal();
		Assert.isTrue(notificationService.findByStudent(student).size() == 3);

	}

	@Test()
	public void editEvaluatedStudentChangeMark() {
		authenticate("professor1");
		EvaluatedStudent evaluatedStudent = evaluatedStudentService.findOne(34);
		evaluatedStudent.setMark(10.0);
		evaluatedStudent = evaluatedStudentService.save(evaluatedStudent);
		Assert.isTrue(evaluatedStudent.getRegistration().getFinalMark()
				.equals(10.0));

		authenticate("student1");
		Student student = studentService.findByPrincipal();
		Assert.isTrue(notificationService.findByStudent(student).size() == 3);

	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeEditEvaluatedStudent_UnfinishedEvaluation() {
		authenticate("professor2");
		EvaluatedStudent evaluatedStudent = evaluatedStudentService.findOne(37);
		evaluatedStudent.setMark(10.0);
		evaluatedStudentService.save(evaluatedStudent);

	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeEditEvaluatedStudent_WrongPrincipal() {
		authenticate("professor2");
		EvaluatedStudent evaluatedStudent = evaluatedStudentService.findOne(34);
		evaluatedStudent.setMark(10.0);
		evaluatedStudentService.save(evaluatedStudent);

	}

	@Test(expected = ConstraintViolationException.class)
	public void negativeEditEvaluatedStudent_NegativeMark() {
		authenticate("professor1");
		EvaluatedStudent evaluatedStudent = evaluatedStudentService.findOne(34);
		evaluatedStudent.setMark(-10.0);
		evaluatedStudentService.save(evaluatedStudent);

	}
}
