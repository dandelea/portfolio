package tutorship;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.util.Assert;

import security.LoginService;
import services.NotificationService;
import services.StudentService;
import services.SubjectService;
import services.TutorshipService;
import utilities.PopulateDatabase;
import domain.Subject;
import domain.Tutorship;
import domain.WeekDay;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class TutorshipEditTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private TutorshipService tutorshipService;

	@Autowired
	private SubjectService subjectService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test()
	public void editTutorshipTest() {
		authenticate("professor1");
		Tutorship tutorship = tutorshipService.findOne(19);
		tutorship.setEndTime(new Date(2015, 12, 4, 19, 30, 0));
		tutorship.setWeekDay(WeekDay.FRIDAY);

		tutorship = tutorshipService.save(tutorship);
		Assert.isTrue(tutorship.getWeekDay().equals(WeekDay.FRIDAY));

	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeEditTutorshipTest_WrongPrincipal() {
		authenticate("professor2");
		Tutorship tutorship = tutorshipService.findOne(19);
		tutorship.setEndTime(new Date(2015, 12, 4, 19, 30, 0));
		tutorship.setWeekDay(WeekDay.FRIDAY);

		tutorshipService.save(tutorship);

	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeEditTutorshipTest_WrongDates() {
		authenticate("professor1");
		Tutorship tutorship = tutorshipService.findOne(19);
		tutorship.setStartTime(new Date(2015, 12, 4, 8, 30, 0));
		tutorship.setEndTime(new Date(2015, 12, 4, 6, 30, 0));
		tutorship.setWeekDay(WeekDay.FRIDAY);

		tutorshipService.save(tutorship);

	}

	@Test(expected = TransactionSystemException.class)
	public void negativeEditTutorshipTest_NullDay() {
		authenticate("professor1");
		Tutorship tutorship = tutorshipService.findOne(19);
		tutorship.setWeekDay(null);

		tutorshipService.save(tutorship);

	}

}
