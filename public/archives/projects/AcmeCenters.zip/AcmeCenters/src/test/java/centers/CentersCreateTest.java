package centers;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.util.Assert;

import security.LoginService;
import services.CenterService;
import utilities.PopulateDatabase;
import domain.Center;
import domain.Dependency;
import domain.Location;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class CentersCreateTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private CenterService centerService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test()
	public void createCenter() {
		authenticate("professor2");
		Center c = centerService.create();
		c.setAddress("Calle A, n� 5");
		c.setCode("code c");
		c.setDependency(Dependency.PUBLIC);
		c.setDescription("Escuela de Arte");
		c.setLocation(new Location());
		c.getLocation().setLatitude(3.9);
		c.getLocation().setLongitude(8.0);
		c.setName("Picasso");
		c.setPostalCode("38450");
		Center center = centerService.save(c);
		Assert.isTrue(!(center.getId() == 0));
	}

	@Test(expected = IllegalArgumentException.class)
	public void createCenter_BadAuthentication() {
		authenticate("student2");
		Center c = centerService.create();
		c.setAddress("Calle A, n� 5");
		c.setCode("code c");
		c.setDependency(Dependency.PUBLIC);
		c.setDescription("Escuela de Arte");
		c.setLocation(new Location());
		c.getLocation().setLatitude(3.9);
		c.getLocation().setLongitude(8.0);
		c.setName("Picasso");
		c.setPostalCode("38450");
		Center center = centerService.save(c);
		Assert.isTrue(!(center.getId() == 0));
	}

	@Test(expected = TransactionSystemException.class)
	public void createCenter_AddressBlank() {

		authenticate("professor2");
		Center c = centerService.create();
		c.setAddress("");
		c.setCode("code c");
		c.setDependency(Dependency.PUBLIC);
		c.setDescription("Escuela de Arte");
		c.setLocation(new Location());
		c.getLocation().setLatitude(3.9);
		c.getLocation().setLongitude(8.0);
		c.setName("Picasso");
		c.setPostalCode("38450");
		Center center = centerService.save(c);
		Assert.isTrue(!(center.getId() == 0));
	}

	@Test(expected = TransactionSystemException.class)
	public void createCenter_AddressNull() {
		authenticate("professor2");
		Center c = centerService.create();
		c.setAddress(null);
		c.setCode("code c");
		c.setDependency(Dependency.PUBLIC);
		c.setDescription("Escuela de Arte");
		c.setLocation(new Location());
		c.getLocation().setLatitude(3.9);
		c.getLocation().setLongitude(8.0);
		c.setName("Picasso");
		c.setPostalCode("38450");
		Center center = centerService.save(c);
		Assert.isTrue(!(center.getId() == 0));
	}

	@Test(expected = TransactionSystemException.class)
	public void createCenter_CodeBlank() {
		authenticate("professor2");
		Center c = centerService.create();
		c.setAddress("Calle A, n� 5");
		c.setCode("");
		c.setDependency(Dependency.PUBLIC);
		c.setDescription("Escuela de Arte");
		c.setLocation(new Location());
		c.getLocation().setLatitude(3.9);
		c.getLocation().setLongitude(8.0);
		c.setName("Picasso");
		c.setPostalCode("38450");
		Center center = centerService.save(c);
		Assert.isTrue(!(center.getId() == 0));
	}

	@Test(expected = TransactionSystemException.class)
	public void createCenter_CodeNull() {
		authenticate("professor2");
		Center c = centerService.create();
		c.setAddress("Calle A, n� 5");
		c.setCode(null);
		c.setDependency(Dependency.PUBLIC);
		c.setDescription("Escuela de Arte");
		c.setLocation(new Location());
		c.getLocation().setLatitude(3.9);
		c.getLocation().setLongitude(8.0);
		c.setName("Picasso");
		c.setPostalCode("38450");
		Center center = centerService.save(c);
		Assert.isTrue(!(center.getId() == 0));
	}

	@Test(expected = TransactionSystemException.class)
	public void createCenter_DependencyNull() {
		authenticate("professor2");
		Center c = centerService.create();
		c.setAddress("Calle A, n� 5");
		c.setCode("code c");
		c.setDependency(null);
		c.setDescription("Escuela de Arte");
		c.setLocation(new Location());
		c.getLocation().setLatitude(3.9);
		c.getLocation().setLongitude(8.0);
		c.setName("Picasso");
		c.setPostalCode("38450");
		Center center = centerService.save(c);
		Assert.isTrue(!(center.getId() == 0));
	}

	@Test(expected = TransactionSystemException.class)
	public void createCenter_DescriptionBlank() {
		authenticate("professor2");
		Center c = centerService.create();
		c.setAddress("Calle A, n� 5");
		c.setCode("code c");
		c.setDependency(Dependency.PUBLIC);
		c.setDescription("");
		c.setLocation(new Location());
		c.getLocation().setLatitude(3.9);
		c.getLocation().setLongitude(8.0);
		c.setName("Picasso");
		c.setPostalCode("38450");
		Center center = centerService.save(c);
		Assert.isTrue(!(center.getId() == 0));
	}

	@Test(expected = TransactionSystemException.class)
	public void createCenter_DescriptionNull() {
		authenticate("professor2");
		Center c = centerService.create();
		c.setAddress("Calle A, n� 5");
		c.setCode("code c");
		c.setDependency(Dependency.PUBLIC);
		c.setDescription(null);
		c.setLocation(new Location());
		c.getLocation().setLatitude(3.9);
		c.getLocation().setLongitude(8.0);
		c.setName("Picasso");
		c.setPostalCode("38450");
		Center center = centerService.save(c);
		Assert.isTrue(!(center.getId() == 0));
	}

	@Test(expected = NullPointerException.class)
	public void createCenter_LocationNull() {
		authenticate("professor2");
		Center c = centerService.create();
		c.setAddress("Calle A, n� 5");
		c.setCode("code c");
		c.setDependency(Dependency.PUBLIC);
		c.setDescription("Escuela de Arte");
		c.setLocation(null);
		c.getLocation().setLatitude(3.9);
		c.getLocation().setLongitude(8.0);
		c.setName("Picasso");
		c.setPostalCode("38450");
		Center center = centerService.save(c);
		Assert.isTrue(!(center.getId() == 0));
	}

	@Test(expected = IllegalArgumentException.class)
	public void createCenter_BadLatitudeAndLongitude() {
		authenticate("professor2");
		Center c = centerService.create();
		c.setAddress("Calle A, n� 5");
		c.setCode("code c");
		c.setDependency(Dependency.PUBLIC);
		c.setDescription("Escuela de Arte");
		c.setLocation(new Location());
		c.setName("Picasso");
		c.setPostalCode("38450");
		Center center = centerService.save(c);
		Assert.isTrue(!(center.getId() == 0));
	}

	@Test(expected = TransactionSystemException.class)
	public void createCenter_NameBlank() {
		authenticate("professor2");
		Center c = centerService.create();
		c.setAddress("Calle A, n� 5");
		c.setCode("code c");
		c.setDependency(Dependency.PUBLIC);
		c.setDescription("Escuela de Arte");
		c.setLocation(new Location());
		c.getLocation().setLatitude(3.9);
		c.getLocation().setLongitude(8.0);
		c.setName("");
		c.setPostalCode("38450");
		Center center = centerService.save(c);
		Assert.isTrue(!(center.getId() == 0));
	}

	@Test(expected = TransactionSystemException.class)
	public void createCenter_NameNull() {
		authenticate("professor2");
		Center c = centerService.create();
		c.setAddress("Calle A, n� 5");
		c.setCode("code c");
		c.setDependency(Dependency.PUBLIC);
		c.setDescription("Escuela de Arte");
		c.setLocation(new Location());
		c.getLocation().setLatitude(3.9);
		c.getLocation().setLongitude(8.0);
		c.setName(null);
		c.setPostalCode("38450");
		Center center = centerService.save(c);
		Assert.isTrue(!(center.getId() == 0));
	}

	@Test(expected = TransactionSystemException.class)
	public void createCenter_PostalCodeBlank() {
		authenticate("professor2");
		Center c = centerService.create();
		c.setAddress("Calle A, n� 5");
		c.setCode("code c");
		c.setDependency(Dependency.PUBLIC);
		c.setDescription("Escuela de Arte");
		c.setLocation(new Location());
		c.getLocation().setLatitude(3.9);
		c.getLocation().setLongitude(8.0);
		c.setName("Picasso");
		c.setPostalCode("");
		Center center = centerService.save(c);
		Assert.isTrue(!(center.getId() == 0));
	}

	@Test(expected = TransactionSystemException.class)
	public void createCenter_PostalCodeNull() {
		authenticate("professor2");
		Center c = centerService.create();
		c.setAddress("Calle A, n� 5");
		c.setCode("code c");
		c.setDependency(Dependency.PUBLIC);
		c.setDescription("Escuela de Arte");
		c.setLocation(new Location());
		c.getLocation().setLatitude(3.9);
		c.getLocation().setLongitude(8.0);
		c.setName("Picasso");
		c.setPostalCode(null);
		Center center = centerService.save(c);
		Assert.isTrue(!(center.getId() == 0));
	}

}
