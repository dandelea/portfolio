package tutorship;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.util.Assert;

import security.LoginService;
import services.ProposalService;
import services.SubjectService;
import utilities.PopulateDatabase;
import domain.Proposal;
import domain.Subject;
import domain.Tutorship;
import domain.WeekDay;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class ProposalCreateTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private ProposalService proposalService;

	@Autowired
	private SubjectService subjectService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test()
	public void createProposalTest() {
		authenticate("student1");
		Subject subject = subjectService.findOne(15);
		Proposal proposal = proposalService.create(subject);
		proposal.setProposedDate(new Date(114, 11, 8, 11, 30, 0));
		proposal = proposalService.save(proposal);

		Assert.isTrue(proposal.getId() != 0);

	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeCreateProposalTest_WrongPrincipal() {
		authenticate("student1");
		Subject subject = subjectService.findOne(15);
		Proposal proposal = proposalService.create(subject);
		proposal.setProposedDate(new Date(114, 11, 8, 11, 30, 0));
		authenticate("student2");
		proposalService.save(proposal);

	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeCreateProposalTest_WrongSubject() {
		authenticate("student1");
		Subject subject = subjectService.findOne(18);
		Proposal proposal = proposalService.create(subject);
		proposal.setProposedDate(new Date(114, 11, 8, 11, 30, 0));
		proposalService.save(proposal);

	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeCreateProposalTest_PastDate() {
		authenticate("student1");
		Subject subject = subjectService.findOne(15);
		Proposal proposal = proposalService.create(subject);
		proposal.setProposedDate(new Date(113, 11, 8, 11, 30, 0));
		proposalService.save(proposal);

	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeCreateProposalTest_NoTutorship1() {
		authenticate("student1");
		Subject subject = subjectService.findOne(15);
		Proposal proposal = proposalService.create(subject);
		proposal.setProposedDate(new Date(114, 11, 8, 13, 30, 0));
		proposalService.save(proposal);

	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeCreateProposalTest_NoTutorship2() {
		authenticate("student1");
		Subject subject = subjectService.findOne(15);
		Proposal proposal = proposalService.create(subject);
		proposal.setProposedDate(new Date(114, 11, 10, 11, 30, 0));
		proposalService.save(proposal);

	}

}
