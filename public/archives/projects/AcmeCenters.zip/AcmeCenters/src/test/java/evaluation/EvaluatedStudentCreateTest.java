package evaluation;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import security.LoginService;
import services.EvaluatedStudentService;
import services.EvaluationService;
import services.NotificationService;
import services.StudentService;
import utilities.PopulateDatabase;
import domain.EvaluatedStudent;
import domain.Evaluation;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class EvaluatedStudentCreateTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private EvaluatedStudentService evaluatedStudentService;

	@Autowired
	private EvaluationService evaluationService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test()
	public void createEvaluatedStudent() {
		authenticate("student1");
		Evaluation evaluation = evaluationService.findOne(31);
		EvaluatedStudent evaluatedStudent = evaluatedStudentService
				.register(evaluation);

		Assert.isTrue(evaluatedStudent.getId() != 0);

	}

	@Test(expected = DataIntegrityViolationException.class)
	public void negativeCreateEvaluatedStudent_RepeatedEvaluatedStudent() {
		authenticate("student2");
		Evaluation evaluation = evaluationService.findOne(32);
		evaluatedStudentService.register(evaluation);

	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeCreateEvaluatedStudent_NullEvaluation() {
		authenticate("student1");
		Evaluation evaluation = null;
		evaluatedStudentService.register(evaluation);

	}

}
