package centers;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import security.LoginService;
import services.CenterService;
import services.MembershipService;
import utilities.PopulateDatabase;
import domain.Center;
import domain.Membership;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class CentersProfessorTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private CenterService centerService;

	@Autowired
	private MembershipService membershipService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test
	public void ProfessorToCenter() {
		authenticate("professor1");
		Center center = centerService.findOne(12);
		Membership m = membershipService.create(center);
		Membership ms = membershipService.save(m);
		Assert.isTrue(!(ms.getId() == 0));
	}

	@Test(expected = IllegalArgumentException.class)
	public void ProfessorToCenter_BadAuthentication() {
		authenticate("student1");
		Center center = centerService.findOne(10);
		Membership m = membershipService.create(center);
		Membership ms = membershipService.save(m);
		Assert.isTrue(!(ms.getId() == 0));
	}

	@Test(expected = IllegalArgumentException.class)
	public void ProfessorToCenter_NotValidProfessor() {
		authenticate("professor2");
		Center center = centerService.findOne(10);
		Membership m = membershipService.create(center);
		Membership ms = membershipService.save(m);
		Assert.isTrue(!(ms.getId() == 0));
	}
}
