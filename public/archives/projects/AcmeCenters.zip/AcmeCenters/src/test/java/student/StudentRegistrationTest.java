package student;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.util.Assert;

import services.StudentService;
import utilities.PopulateDatabase;
import domain.Student;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class StudentRegistrationTest {

	@Autowired
	private StudentService studentService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	@Test
	public void registerNewStudent() {
		System.out.println("Registrar un nuevo estudiante");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_Name_Null() {
		System.out.println("Registrar un nuevo estudiante con nombre nulo");
		Student student = studentService.create();
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_Name_Blank() {
		System.out.println("Registrar un nuevo estudiante con nombre vacio");
		Student student = studentService.create();
		student.setName("");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_Surname_Null() {
		System.out.println("Registrar un nuevo estudiante con apellido nulo");
		Student student = studentService.create();
		student.setName("Name");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_Surname_Blank() {
		System.out.println("Registrar un nuevo estudiante con apellido vacio");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_Email_Null() {
		System.out.println("Registrar un nuevo estudiante con email nulo");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_Email_Blank() {
		System.out.println("Registrar un nuevo estudiante con email vacio");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_Email_WrongPattern() {
		System.out
				.println("Registrar un nuevo estudiante con email incorrecto");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_Phone_Null() {
		System.out.println("Registrar un nuevo estudiante con tel�fono nulo");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_Phone_Blank() {
		System.out.println("Registrar un nuevo estudiante con tel�fono vacio");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_Phone_WrongPattern() {
		System.out
				.println("Registrar un nuevo estudiante con tel�fono incorrecto");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("123");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_NameAndSurnamesFather_Null() {
		System.out
				.println("Registrar un nuevo estudiante con nombre/apellidos padre nulo");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_NameAndSurnamesMother_Null() {
		System.out
				.println("Registrar un nuevo estudiante con nombre/apellidos madre nulo");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_NameAndSurnamesFather_Blank() {
		System.out
				.println("Registrar un nuevo estudiante con nombre/apellidos padre vacio");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_NameAndSurnamesMother_Blank() {
		System.out
				.println("Registrar un nuevo estudiante con nombre/apellidos madre vacio");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_Interests_Null() {
		System.out.println("Registrar un nuevo estudiante con intereses nulos");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_Interests_Blank() {
		System.out
				.println("Registrar un nuevo estudiante con intereses vacios");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_IllnessesAndDissabilities_Null() {
		System.out
				.println("Registrar un nuevo estudiante con enfermedades nulo");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_Address_Null() {
		System.out.println("Registrar un nuevo estudiante con direccion nulo");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_Address_Blank() {
		System.out.println("Registrar un nuevo estudiante con direccion vacio");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_Username_WrongLength() {
		System.out
				.println("Registrar un nuevo estudiante con nombre de usuario longitud incorrecta");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("u");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = DataIntegrityViolationException.class)
	public void negativeTest_RegisterNewStudent_Username_AlreadyUsed() {
		System.out
				.println("Registrar un nuevo estudiante con nombre de usuario ya en uso");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("student1");
		student.getUserAccount().setPassword("password");
		Assert.notNull(studentService.save(student));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewStudent_Password_WrongLength() {
		System.out
				.println("Registrar un nuevo estudiante con contrase�a longitud incorrecta");
		Student student = studentService.create();
		student.setName("Name");
		student.setSurname("Surname");
		student.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		student.setPicture(data);
		student.setPhone("111111111");
		student.setNameAndSurnamesFather("NameAndSurnamesFather");
		student.setNameAndSurnamesMother("NameAndSurnamesMother");
		student.setInterests("Interests");
		student.setIllnessesAndDissabilities("IllnessesAndDissabilities");
		student.setAddress("Address");
		student.getUserAccount().setUsername("username");
		student.getUserAccount().setPassword("p");
		Assert.notNull(studentService.save(student));
	}

}
