package professor;

import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import security.LoginService;
import services.CenterService;
import services.MembershipService;
import services.ProfessorService;
import utilities.PopulateDatabase;
import domain.Center;
import domain.Membership;
import domain.Professor;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class ProfessorListsTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private ProfessorService professorService;

	@Autowired
	private CenterService centerService;

	@Autowired
	private MembershipService membershipService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test
	public void listProfessorsFromCenter() {
		System.out.println("Listar los profesores de un centro");
		Center center = centerService.findOne(11);
		Collection<Professor> professors = professorService
				.findProfessorsByCenter(center);
		for (Professor professor : professors) {
			Collection<Membership> memberships = membershipService
					.findByProfessor(professor);
			// Alguna membres�a es del centro
			boolean any = false;
			for (Membership membership : memberships) {
				any = any || membership.getCenter().equals(center);
			}
			Assert.isTrue(any);
		}
	}

}
