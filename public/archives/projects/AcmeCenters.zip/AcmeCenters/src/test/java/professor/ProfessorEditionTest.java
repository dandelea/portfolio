package professor;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.util.Assert;

import security.LoginService;
import services.ProfessorService;
import utilities.PopulateDatabase;
import domain.Professor;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class ProfessorEditionTest {
	@Autowired
	private LoginService loginService;
	@Autowired
	private ProfessorService professorService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test
	public void editProfile() {
		System.out.println("Editar el perfil");
		authenticate("professor1");
		Professor professor = professorService.findOne(6);
		professor.setName("Name");
		professor.setSurname("Surname");
		professor.setEmail("email@mail.com");
		professor.setCurriculum("Curriculum");
		Assert.notNull(professorService.save(professor));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_EditProfile_Name_Blank() {
		System.out.println("Editar el perfil con nombre vacio");
		authenticate("professor1");
		Professor professor = professorService.findOne(6);
		professor.setName("");
		professor.setSurname("Surname");
		professor.setEmail("email@mail.com");
		professor.setCurriculum("Curriculum");
		Assert.notNull(professorService.save(professor));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_EditProfile_Surname_Blank() {
		System.out.println("Editar el perfil con apellido vacio");
		authenticate("professor1");
		Professor professor = professorService.findOne(6);
		professor.setName("Name");
		professor.setSurname("");
		professor.setEmail("email@mail.com");
		professor.setCurriculum("Curriculum");
		Assert.notNull(professorService.save(professor));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_EditProfile_Email_Blank() {
		System.out.println("Editar el perfil con email vacio");
		authenticate("professor1");
		Professor professor = professorService.findOne(6);
		professor.setName("Name");
		professor.setSurname("Surname");
		professor.setEmail("");
		professor.setCurriculum("Curriculum");
		Assert.notNull(professorService.save(professor));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_EditProfile_Email_WrongPattern() {
		System.out.println("Editar el perfil con email incorrecto");
		authenticate("professor1");
		Professor professor = professorService.findOne(6);
		professor.setName("Name");
		professor.setSurname("Surname");
		professor.setEmail("email");
		professor.setCurriculum("Curriculum");
		Assert.notNull(professorService.save(professor));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_EditProfile_Curriculum_Blank() {
		System.out.println("Editar el perfil con curriculum vacio");
		authenticate("professor1");
		Professor professor = professorService.findOne(6);
		professor.setName("Name");
		professor.setSurname("Surname");
		professor.setEmail("email@mail.com");
		professor.setCurriculum("");
		Assert.notNull(professorService.save(professor));
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeTest_EditProfile_NotPrincipal() {
		System.out.println("Editar el perfil por otro usuario");
		authenticate("professor2");
		Professor professor = professorService.findOne(6);
		professor.setName("Name");
		professor.setSurname("Surname");
		professor.setEmail("email@mail.com");
		professor.setCurriculum("Curriculum");
		Assert.notNull(professorService.save(professor));
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeTest_EditProfile_AStudent() {
		System.out.println("Editar el perfil por un estudiante");
		authenticate("student1");
		Professor professor = professorService.findOne(6);
		professor.setName("Name");
		professor.setSurname("Surname");
		professor.setEmail("email@mail.com");
		professor.setCurriculum("Curriculum");
		Assert.notNull(professorService.save(professor));
	}

}
