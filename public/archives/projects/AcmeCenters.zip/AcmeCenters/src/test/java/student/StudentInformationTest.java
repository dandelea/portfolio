package student;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import security.LoginService;
import services.StudentService;
import utilities.PopulateDatabase;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class StudentInformationTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private StudentService studentService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test
	public void seeStudentInformationStudent() {
		System.out
				.println("Acceder a la informacion de un estudiante por si mismo");
		authenticate("student1");
		// Student 1
		Assert.notNull(studentService.findOne(9));
	}

	@Test
	public void seeStudentInformationProfessor() {
		System.out
				.println("Acceder a la informacion de un estudiante por su profesor");
		authenticate("professor1");
		// Student 1
		Assert.notNull(studentService.findOne(9));
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeTest_SeetStudentInformation_OtherStudent() {
		System.out
				.println("Acceder a la informacion de un estudiante por otro alumno");
		authenticate("student2");
		// Student 1
		Assert.notNull(studentService.findOne(9));
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeTest_SeeStudentInformation_OtherProfessor() {
		System.out
				.println("Acceder a la informacion de un estudiante por otro profesor");
		authenticate("professor3");
		// Student 1
		Assert.notNull(studentService.findOne(9));
	}

}
