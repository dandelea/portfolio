package tutorship;

import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import security.LoginService;
import services.SubjectService;
import services.TutorshipService;
import utilities.PopulateDatabase;
import domain.Subject;
import domain.Tutorship;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class TutorshipDeleteTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private TutorshipService tutorshipService;

	@Autowired
	private SubjectService subjectService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test()
	public void deleteTutorshipTest() {
		authenticate("professor1");
		Tutorship tutorship = tutorshipService.findOne(19);
		Subject subject = subjectService.findOne(15);
		tutorshipService.delete(tutorship);

		Collection<Tutorship> tutorships = tutorshipService
				.findBySubject(subject);
		Assert.isTrue(tutorships.size() == 1);

	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeDeleteTutorshipTest_WrongPrincipal() {
		authenticate("professor2");
		Tutorship tutorship = tutorshipService.findOne(19);
		Subject subject = subjectService.findOne(15);
		tutorshipService.delete(tutorship);

	}

}
