package subject;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import security.LoginService;
import services.RegistrationService;
import services.SubjectService;
import utilities.PopulateDatabase;
import domain.Registration;
import domain.Subject;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class SubjectStudentTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private SubjectService subjectService;

	@Autowired
	private RegistrationService registrationService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test
	public void StudentInSubject() {
		authenticate("student1");
		Subject subject = subjectService.findOne(18);
		Integer tam = subject.getNumberStudents();
		Registration r = registrationService.create(subject);
		registrationService.save(r);
		Integer tam2 = subject.getNumberStudents();
		Assert.isTrue(tam.equals(tam2 - 1));
	}

	@Test(expected = IllegalArgumentException.class)
	public void StudentInSubject_NotValidSubject() {
		authenticate("student1");
		Subject subject = subjectService.findOne(15);
		Integer tam = subject.getNumberStudents();
		Registration r = registrationService.create(subject);
		registrationService.save(r);
		Integer tam2 = subject.getNumberStudents();
		Assert.isTrue(tam.equals(tam2 - 1));
	}

	@Test(expected = IllegalArgumentException.class)
	public void StudentInSubject_BadAuthentication() {
		authenticate("professor1");
		Subject subject = subjectService.findOne(16);
		Integer tam = subject.getNumberStudents();
		Registration r = registrationService.create(subject);
		registrationService.save(r);
		Integer tam2 = subject.getNumberStudents();
		Assert.isTrue(tam.equals(tam2 - 1));
	}
}
