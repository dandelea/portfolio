package notification;

import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import security.LoginService;
import services.NotificationService;
import services.StudentService;
import utilities.PopulateDatabase;
import domain.Notification;
import domain.Student;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class NotificationListsTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private StudentService studentService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test
	public void listNotificationsFromStudent() {
		System.out.println("Listar las notificaciones de un estudiante");
		authenticate("student1");
		Student student = studentService.findByPrincipal();
		Collection<Notification> notifications = notificationService
				.findByStudent(student);
		for (Notification notification : notifications) {
			Assert.isTrue(notification.getStudent().equals(student));
		}
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeTest_ListNotificationsFromStudent_WrongStudent() {
		System.out.println("Listar las notificaciones de otro estudiante");
		authenticate("student1");
		Student student1 = studentService.findByPrincipal();
		Collection<Notification> notifications = notificationService
				.findByStudent(student1);
		// Cambiar de usuario
		authenticate("student2");
		Student student2 = studentService.findByPrincipal();
		for (Notification notification : notifications) {
			Assert.isTrue(notification.getStudent().equals(student2));
		}
	}

}
