package subject;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.util.Assert;

import security.LoginService;
import services.CenterService;
import services.MembershipService;
import services.SubjectService;
import utilities.PopulateDatabase;
import domain.Center;
import domain.Membership;
import domain.Subject;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class SubjectCreateTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private SubjectService subjectService;

	@Autowired
	private CenterService centerService;

	@Autowired
	private MembershipService membershipService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test
	public void createSubject() {
		authenticate("professor1");
		Subject s = subjectService.create();
		s.setName("Subject p1");
		s.setGrade(2);
		s.setMaximumNumberStudents(3);
		s.setRegistrationLimit(new Date());
		Center center = centerService.findOne(12);
		Membership m = membershipService.create(center);
		Membership ms = membershipService.save(m);
		s.setMembership(ms);
		Subject subject = subjectService.save(s);
		Assert.isTrue(!(subject.getId() == 0));

	}

	@Test(expected = IllegalArgumentException.class)
	public void createSubject_BadAuthentication() {
		authenticate("student1");
		Subject s = subjectService.create();
		s.setName("Subject p1");
		s.setGrade(2);
		s.setMaximumNumberStudents(30);
		s.setRegistrationLimit(new Date());
		Center center = centerService.findOne(10);
		Membership m = membershipService.create(center);
		Membership ms = membershipService.save(m);
		s.setMembership(ms);
		Subject subject = subjectService.save(s);
		Assert.isTrue(!(subject.getId() == 0));

	}

	@Test(expected = TransactionSystemException.class)
	public void createSubject_NameBlank() {
		authenticate("professor1");
		Subject s = subjectService.create();
		s.setName("");
		s.setGrade(2);
		s.setMaximumNumberStudents(30);
		s.setRegistrationLimit(new Date());
		Center center = centerService.findOne(12);
		Membership m = membershipService.create(center);
		Membership ms = membershipService.save(m);
		s.setMembership(ms);
		Subject subject = subjectService.save(s);
		Assert.isTrue(!(subject.getId() == 0));

	}

	@Test(expected = TransactionSystemException.class)
	public void createSubject_nameNull() {
		authenticate("professor1");
		Subject s = subjectService.create();
		s.setName(null);
		s.setGrade(2);
		s.setMaximumNumberStudents(30);
		s.setRegistrationLimit(new Date());
		Center center = centerService.findOne(12);
		Membership m = membershipService.create(center);
		Membership ms = membershipService.save(m);
		s.setMembership(ms);
		Subject subject = subjectService.save(s);
		Assert.isTrue(!(subject.getId() == 0));

	}

	@Test(expected = TransactionSystemException.class)
	public void createSubject_NumberStudent0() {
		authenticate("professor1");
		Subject s = subjectService.create();
		s.setName("Subject p1");
		s.setGrade(5);
		s.setMaximumNumberStudents(0);
		s.setRegistrationLimit(new Date());
		Center center = centerService.findOne(12);
		Membership m = membershipService.create(center);
		Membership ms = membershipService.save(m);
		s.setMembership(ms);
		Subject subject = subjectService.save(s);
		Assert.isTrue(!(subject.getId() == 0));

	}

	@Test(expected = TransactionSystemException.class)
	public void createSubject_Grade0() {
		authenticate("professor1");
		Subject s = subjectService.create();
		s.setName("Subject p1");
		s.setGrade(0);
		s.setMaximumNumberStudents(30);
		s.setRegistrationLimit(new Date());
		Center center = centerService.findOne(12);
		Membership m = membershipService.create(center);
		Membership ms = membershipService.save(m);
		s.setMembership(ms);
		Subject subject = subjectService.save(s);
		Assert.isTrue(!(subject.getId() == 0));

	}

	@Test(expected = TransactionSystemException.class)
	public void createSubject_GradeInvalid() {
		authenticate("professor1");
		Subject s = subjectService.create();
		s.setName("Subject p1");
		s.setGrade(22);
		s.setMaximumNumberStudents(30);
		s.setRegistrationLimit(new Date());
		Center center = centerService.findOne(12);
		Membership m = membershipService.create(center);
		Membership ms = membershipService.save(m);
		s.setMembership(ms);
		Subject subject = subjectService.save(s);
		Assert.isTrue(!(subject.getId() == 0));

	}

	@Test(expected = NullPointerException.class)
	public void createSubject_MembershipNull() {
		authenticate("professor1");
		Subject s = subjectService.create();
		s.setName("Subject p1");
		s.setGrade(2);
		s.setMaximumNumberStudents(30);
		s.setRegistrationLimit(new Date());
		Membership ms = null;
		s.setMembership(ms);
		Subject subject = subjectService.save(s);
		Assert.isTrue(!(subject.getId() == 0));

	}

}
