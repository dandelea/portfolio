package subject;

import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import security.LoginService;
import services.CenterService;
import services.RegistrationService;
import services.SubjectService;
import utilities.PopulateDatabase;
import domain.Center;
import domain.Registration;
import domain.Subject;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class SubjetsListTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private SubjectService subjectService;

	@Autowired
	private CenterService centerService;

	@Autowired
	private RegistrationService registrationService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test
	public void listSubjectsByProfessor() {
		authenticate("professor2");
		Collection<Subject> subjects = subjectService
				.findByPrincipalProfessor();
		Integer tam = subjects.size();
		Assert.isTrue(tam.equals(2));
	}

	@Test(expected = IllegalArgumentException.class)
	public void listSubjectsByProfessor_BadAuthentication() {
		authenticate("student2");
		Collection<Subject> subjects = subjectService
				.findByPrincipalProfessor();
		Integer tam = subjects.size();
		Assert.isTrue(tam.equals(1));
	}

	@Test
	public void listRegistrationsByStudent() {
		authenticate("student2");
		Collection<Registration> registrations = registrationService
				.findByPrincipal();
		Integer tam = registrations.size();
		Assert.isTrue(tam.equals(2));

	}

	@Test
	public void listSubjectsByCenter() {
		Center center = centerService.findOne(12);
		Collection<Subject> subjects = subjectService.findByCenter(center);
		Integer tam = subjects.size();
		Assert.isTrue(tam.equals(2));

	}

	@Test
	public void listAvailableSubjectsByCenter() {
		Center center = centerService.findOne(12);
		Collection<Subject> subjects = subjectService
				.findAvailableByCenter(center);
		Integer tam = subjects.size();
		Assert.isTrue(tam.equals(1));
	}

}
