package professor;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.util.Assert;

import services.ProfessorService;
import utilities.PopulateDatabase;
import domain.Professor;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class ProfessorRegistrationTest {

	@Autowired
	private ProfessorService professorService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	@Test
	public void registerNewProfessor() {
		System.out.println("Registrar un nuevo profesor");
		Professor professor = professorService.create();

		professor.setName("Name");
		professor.setSurname("Surname");
		professor.setCurriculum("Curriculum");
		professor.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		professor.setPicture(data);
		professor.getUserAccount().setUsername("username");
		professor.getUserAccount().setPassword("password");

		Assert.notNull(professorService.register(professor));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewProfessor_Name_Null() {
		System.out.println("Registrar un nuevo profesor con nombre nulo");
		Professor professor = professorService.create();

		professor.setSurname("Surname");
		professor.setCurriculum("Curriculum");
		professor.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		professor.setPicture(data);
		professor.getUserAccount().setUsername("username");
		professor.getUserAccount().setPassword("password");

		Assert.notNull(professorService.register(professor));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewProfessor_Name_Blank() {
		System.out.println("Registrar un nuevo profesor con nombre vacio");
		Professor professor = professorService.create();

		professor.setName("");
		professor.setSurname("Surname");
		professor.setCurriculum("Curriculum");
		professor.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		professor.setPicture(data);
		professor.getUserAccount().setUsername("username");
		professor.getUserAccount().setPassword("password");

		Assert.notNull(professorService.register(professor));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewProfessor_Surname_Null() {
		System.out.println("Registrar un nuevo profesor con apellido nulo");
		Professor professor = professorService.create();

		professor.setName("Name");
		professor.setCurriculum("Curriculum");
		professor.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		professor.setPicture(data);
		professor.getUserAccount().setUsername("username");
		professor.getUserAccount().setPassword("password");

		Assert.notNull(professorService.register(professor));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewProfessor_Surname_Blank() {
		System.out.println("Registrar un nuevo profesor con apellido vacio");
		Professor professor = professorService.create();

		professor.setName("Name");
		professor.setSurname("");
		professor.setCurriculum("Curriculum");
		professor.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		professor.setPicture(data);
		professor.getUserAccount().setUsername("username");
		professor.getUserAccount().setPassword("password");

		Assert.notNull(professorService.register(professor));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewProfessor_Curriculum_Null() {
		System.out.println("Registrar un nuevo profesor con curriculum nulo");
		Professor professor = professorService.create();

		professor.setName("Name");
		professor.setSurname("Surname");
		professor.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		professor.setPicture(data);
		professor.getUserAccount().setUsername("username");
		professor.getUserAccount().setPassword("password");

		Assert.notNull(professorService.register(professor));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewProfessor_Curriculum_Blank() {
		System.out.println("Registrar un nuevo profesor con curriculum vacio");
		Professor professor = professorService.create();

		professor.setName("Name");
		professor.setSurname("Surname");
		professor.setCurriculum("");
		professor.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		professor.setPicture(data);
		professor.getUserAccount().setUsername("username");
		professor.getUserAccount().setPassword("password");

		Assert.notNull(professorService.register(professor));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewProfessor_Email_Null() {
		System.out.println("Registrar un nuevo profesor con email nulo");
		Professor professor = professorService.create();

		professor.setName("Name");
		professor.setSurname("Surname");
		professor.setCurriculum("Curriculum");
		byte[] data = { (byte) 00001111 };
		professor.setPicture(data);
		professor.getUserAccount().setUsername("username");
		professor.getUserAccount().setPassword("password");

		Assert.notNull(professorService.register(professor));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewProfessor_Email_Blank() {
		System.out.println("Registrar un nuevo profesor con email blanco");
		Professor professor = professorService.create();

		professor.setName("Name");
		professor.setSurname("Surname");
		professor.setCurriculum("Curriculum");
		professor.setEmail("");
		byte[] data = { (byte) 00001111 };
		professor.setPicture(data);
		professor.getUserAccount().setUsername("username");
		professor.getUserAccount().setPassword("password");

		Assert.notNull(professorService.register(professor));
	}

	@Test(expected = TransactionSystemException.class)
	public void negativeTest_RegisterNewProfessor_Email_WrongPattern() {
		System.out
				.println("Registrar un nuevo profesor con email patr�n incorrecto");
		Professor professor = professorService.create();

		professor.setName("Name");
		professor.setSurname("Surname");
		professor.setCurriculum("Curriculum");
		professor.setEmail("email");
		byte[] data = { (byte) 00001111 };
		professor.setPicture(data);
		professor.getUserAccount().setUsername("username");
		professor.getUserAccount().setPassword("password");

		Assert.notNull(professorService.register(professor));
	}

	@Test(expected = DataIntegrityViolationException.class)
	public void negativeTest_RegisterNewProfessor_Username_AlreadyUsed() {
		System.out
				.println("Registrar un nuevo profesor con nombre de usuario ya usado");
		Professor professor = professorService.create();

		professor.setName("Name");
		professor.setSurname("Surname");
		professor.setCurriculum("Curriculum");
		professor.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		professor.setPicture(data);
		professor.getUserAccount().setUsername("professor1");
		professor.getUserAccount().setPassword("password");

		Assert.notNull(professorService.register(professor));
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeTest_RegisterNewProfessor_Username_WrongLength() {
		System.out
				.println("Registrar un nuevo profesor con nombre de usuario longitud correcta");
		Professor professor = professorService.create();

		professor.setName("Name");
		professor.setSurname("Surname");
		professor.setCurriculum("Curriculum");
		professor.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		professor.setPicture(data);
		professor.getUserAccount().setUsername("u");
		professor.getUserAccount().setPassword("password");

		Assert.notNull(professorService.register(professor));
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeTest_RegisterNewProfessor_Password_WrongLength() {
		System.out
				.println("Registrar un nuevo profesor con contrase�a longitud correcta");
		Professor professor = professorService.create();

		professor.setName("Name");
		professor.setSurname("Surname");
		professor.setCurriculum("Curriculum");
		professor.setEmail("email@mail.com");
		byte[] data = { (byte) 00001111 };
		professor.setPicture(data);
		professor.getUserAccount().setUsername("username");
		professor.getUserAccount().setPassword("p");

		Assert.notNull(professorService.register(professor));
	}
}
