package evaluation;

import java.util.Collection;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import security.LoginService;
import services.EvaluatedStudentService;
import services.EvaluationService;
import services.StudentService;
import services.SubjectService;
import utilities.PopulateDatabase;
import domain.EvaluatedStudent;
import domain.Evaluation;
import domain.Student;
import domain.Subject;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class EvaluationListTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private EvaluationService evaluationService;

	@Autowired
	private EvaluatedStudentService evaluatedStudentService;

	@Autowired
	private SubjectService subjectService;

	@Autowired
	private StudentService studentService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test()
	public void listBySubject() {
		authenticate("professor1");
		Subject subject = subjectService.findOne(15);
		Collection<Evaluation> evaluations = evaluationService
				.findBySubject(subject);
		Assert.isTrue(evaluations.size() == 2);
		for (Evaluation evaluation : evaluations) {
			Assert.isTrue(evaluation.getSubject().equals(subject));
		}
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeListBySubject_WrongPrincipal() {
		authenticate("professor2");
		Subject subject = subjectService.findOne(15);
		Collection<Evaluation> evaluations = evaluationService
				.findBySubject(subject);
	}

	@Test()
	public void listRegisteredAndFinishedBySubject() {
		authenticate("student1");
		Subject subject = subjectService.findOne(15);
		Collection<EvaluatedStudent> evaluatedStudents = evaluatedStudentService
				.findBySubjectForPrincipalStudent(subject);
		Assert.isTrue(evaluatedStudents.size() == 2);
		for (EvaluatedStudent evaluatedStudent : evaluatedStudents) {
			Assert.isTrue(evaluatedStudent.getEvaluation().getSubject()
					.equals(subject)
					&& evaluatedStudent.getEvaluation().getFinishDate()
							.before(new Date())
					&& evaluatedStudent.getRegistration().getStudent()
							.getUserAccount()
							.equals(LoginService.getPrincipal()));
		}
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeListRegisteredAndFinishedBySubject_WrongRole() {
		authenticate("professor1");
		Subject subject = subjectService.findOne(15);
		Collection<EvaluatedStudent> evaluatedStudents = evaluatedStudentService
				.findBySubjectForPrincipalStudent(subject);
	}

	@Test()
	public void listRegisteredAndFinished() {
		authenticate("student1");
		Student student = studentService.findByPrincipal();
		Collection<EvaluatedStudent> evaluatedStudents = evaluatedStudentService
				.findFinishedByStudent(student);
		Assert.isTrue(evaluatedStudents.size() == 2);
		for (EvaluatedStudent evaluatedStudent : evaluatedStudents) {
			Assert.isTrue(evaluatedStudent.getEvaluation().getFinishDate()
					.before(new Date())
					&& evaluatedStudent.getRegistration().getStudent()
							.getUserAccount()
							.equals(LoginService.getPrincipal()));
		}
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeListRegisteredAndFinished_WrongPrincipal() {
		authenticate("student1");
		Student student = studentService.findByPrincipal();
		authenticate("student2");
		Collection<EvaluatedStudent> evaluatedStudents = evaluatedStudentService
				.findFinishedByStudent(student);
	}

	@Test()
	public void listNotRegisteredAndUnFinishedBySubject() {
		authenticate("student1");
		Subject subject = subjectService.findOne(17);
		Collection<Evaluation> evaluations = evaluationService
				.findNotRegisteredBySubject(subject);
		Assert.isTrue(evaluations.size() == 2);
	}

}
