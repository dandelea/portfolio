package tutorship;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import security.LoginService;
import services.NotificationService;
import services.ProposalService;
import services.StudentService;
import utilities.PopulateDatabase;
import domain.Proposal;
import domain.Student;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class ProposalEditTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private ProposalService proposalService;

	@Autowired
	private StudentService studentService;

	@Autowired
	private NotificationService notificationService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test()
	public void acceptProposalTest() {
		authenticate("professor1");
		Proposal proposal = proposalService.findOne(22);
		proposal = proposalService.accept(proposal);

		Assert.isTrue(proposal.getAccepted() == true);

		authenticate("student1");
		Student student = studentService.findByPrincipal();
		Assert.isTrue(notificationService.findByStudent(student).size() == 3);

	}

	@Test()
	public void editProposalTest() {
		authenticate("professor2");
		Proposal proposal = proposalService.findOne(23);
		proposal = proposalService.decline(proposal);

		Assert.isTrue(proposal.getAccepted() == false);

		authenticate("student2");
		Student student = studentService.findByPrincipal();
		Assert.isTrue(notificationService.findByStudent(student).size() == 1);

	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeEditProposalTest_WrongPrincipal() {
		authenticate("professor1");
		Proposal proposal = proposalService.findOne(23);
		proposal = proposalService.decline(proposal);

	}

}
