package tutorship;

import java.util.Collection;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import security.LoginService;
import services.ProposalService;
import utilities.PopulateDatabase;
import domain.Proposal;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class ProposalListTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private ProposalService proposalService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test()
	public void listByTeacherNotFinished() {
		authenticate("professor1");
		Collection<Proposal> proposals = proposalService
				.findByPrincipalProfessorNotFinished();

		Assert.isTrue(proposals.size() == 1);
		for (Proposal proposal : proposals) {
			Assert.isTrue(proposal.getProposedDate().after(new Date())
					&& proposal.getSubject().getMembership().getProfessor()
							.getUserAccount()
							.equals(LoginService.getPrincipal()));
		}

	}

	@Test()
	public void listByStudentNotFinished() {
		authenticate("student1");
		Collection<Proposal> proposals = proposalService
				.findByPrincipalStudentNotFinished();

		Assert.isTrue(proposals.size() == 1);
		for (Proposal proposal : proposals) {
			Assert.isTrue(proposal.getProposedDate().after(new Date())
					&& proposal.getStudent().getUserAccount()
							.equals(LoginService.getPrincipal()));
		}

	}

}
