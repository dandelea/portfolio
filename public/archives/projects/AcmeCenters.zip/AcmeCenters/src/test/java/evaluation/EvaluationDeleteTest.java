package evaluation;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import security.LoginService;
import services.EvaluationService;
import services.SubjectService;
import utilities.PopulateDatabase;
import domain.Evaluation;
import domain.Subject;

@ContextConfiguration(locations = { "classpath:spring/datasource.xml",
		"classpath:spring/config/packages.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class EvaluationDeleteTest {

	@Autowired
	private LoginService loginService;

	@Autowired
	private EvaluationService evaluationService;

	@Autowired
	private SubjectService subjectService;

	@Before
	public void setUp() {
		System.out.println("Poblar base de datos");
		PopulateDatabase.main(null);
	}

	public void authenticate(String username) {
		UserDetails userDetails;
		TestingAuthenticationToken authenticationToken;
		SecurityContext context;

		userDetails = loginService.loadUserByUsername(username);
		authenticationToken = new TestingAuthenticationToken(userDetails, null);
		context = SecurityContextHolder.getContext();
		context.setAuthentication(authenticationToken);
	}

	@Test()
	public void deleteEvaluation() {
		authenticate("professor2");
		Subject subject = subjectService.findOne(17);
		Evaluation evaluation = evaluationService.findOne(31);
		evaluationService.delete(evaluation);

		Assert.isTrue(evaluationService.findBySubject(subject).size() == 2);
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeDeleteEvaluation_WrongPrincipal() {
		authenticate("professor1");
		Evaluation evaluation = evaluationService.findOne(31);
		evaluationService.delete(evaluation);
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeDeleteEvaluation_EvaluationWithStudents() {
		authenticate("professor1");
		Evaluation evaluation = evaluationService.findOne(29);
		evaluationService.delete(evaluation);
	}

	@Test(expected = IllegalArgumentException.class)
	public void negativeDeleteEvaluation_FinishedEvaluation() {
		authenticate("professor2");
		Evaluation evaluation = evaluationService.findOne(33);
		evaluationService.delete(evaluation);
	}

}
