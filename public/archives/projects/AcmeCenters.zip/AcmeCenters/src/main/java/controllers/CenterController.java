package controllers;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import security.LoginService;
import security.UserAccount;
import services.CenterService;
import services.MembershipService;
import domain.Center;
import domain.Membership;
import forms.CenterSearchForm;

@Controller
@RequestMapping("/center")
public class CenterController extends AbstractController {

	@Autowired
	private CenterService centerService;

	@Autowired
	private MembershipService membershipService;

	// Constructors -----------------------------------------------------------

	public CenterController() {
		super();
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	private ModelAndView list() {
		ModelAndView result;

		Collection<Center> centers = centerService.findAll();

		result = new ModelAndView("center/list");
		result.addObject("centers", centers);

		return result;
	}

	@RequestMapping(value = "/search", method = RequestMethod.GET)
	private ModelAndView search() {
		ModelAndView result;

		CenterSearchForm centerSearchForm = new CenterSearchForm();

		result = new ModelAndView("center/search");
		result.addObject("centerSearchForm", centerSearchForm);

		return result;
	}

	@RequestMapping(value = "/search", method = RequestMethod.POST, params = "save")
	public ModelAndView search(@Valid CenterSearchForm centerSearchForm,
			BindingResult binding) {
		ModelAndView result;
		Collection<Center> centers;

		if (binding.hasErrors()) {
			result = new ModelAndView("center/search");
			result.addObject("centerSearchForm", centerSearchForm);
		} else {
			try {
				centers = centerService.search(centerSearchForm);
				result = new ModelAndView("center/list");
				result.addObject("centers", centers);
			} catch (Throwable oops) {
				result = new ModelAndView("center/search");
				result.addObject("centerSearchForm", centerSearchForm);
				result.addObject("message", "center.commit.error");
			}
		}
		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam int centerId) {
		Center center = centerService.findOne(centerId);
		return createEditModelAndView(center);
	}

	private ModelAndView createEditModelAndView(Center center) {
		ModelAndView result;

		result = createEditModelAndView(center, null);

		return result;
	}

	private ModelAndView createEditModelAndView(Center center, String message) {
		ModelAndView result;
		boolean isProfessor = false;

		if (center.getId() > 0) {

			Collection<Membership> memberships = membershipService
					.findByCenter(center);

			// El try-catch evita que no se muestre la p�gina si se hace la
			// comprobaci�n siendo un usuario an�nimo
			try {
				UserAccount principal = LoginService.getPrincipal();
				for (Membership membership : memberships) {
					if (membership.getProfessor().getUserAccount()
							.equals(principal)) {
						isProfessor = true;
					}
				}
			} catch (IllegalArgumentException e) {

			}
		}

		result = new ModelAndView("center/edit");
		result.addObject("center", center);
		result.addObject("isProfessor", isProfessor);
		result.addObject("message", message);

		return result;
	}

}
