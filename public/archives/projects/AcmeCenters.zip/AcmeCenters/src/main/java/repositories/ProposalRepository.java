package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Proposal;

@Repository
public interface ProposalRepository extends JpaRepository<Proposal, Integer> {

	@Query("select p from Proposal p where p.subject.membership.professor.id=?1")
	public Collection<Proposal> findByProfessorId(int id);

	@Query("select p from Proposal p where p.student.id=?1")
	public Collection<Proposal> findByStudentId(int id);

	@Query("select p from Proposal p where p.proposedDate>CURRENT_DATE and p.subject.membership.professor.id=?1")
	public Collection<Proposal> findNotFinishedByProfessorId(int id);

	@Query("select p from Proposal p where p.proposedDate>CURRENT_DATE and p.student.id=?1")
	public Collection<Proposal> findNotFinishedByStudentId(int id);

}
