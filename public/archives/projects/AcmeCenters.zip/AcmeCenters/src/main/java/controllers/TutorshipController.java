package controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import security.Authority;
import security.LoginService;
import services.ProposalService;
import services.SubjectService;
import services.TutorshipService;
import domain.Proposal;
import domain.Subject;
import domain.Tutorship;

@Controller
@RequestMapping("/tutorship")
public class TutorshipController extends AbstractController {

	// Support services
	@Autowired
	private TutorshipService tutorshipService;
	@Autowired
	private SubjectService subjectService;
	@Autowired
	private ProposalService proposalService;

	// Constructor
	public TutorshipController() {
		super();
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam int subjectId) {
		ModelAndView res;
		Subject subject = subjectService.findOne(subjectId);
		Collection<Tutorship> tutorships;
		tutorships = tutorshipService.findBySubject(subject);
		Proposal proposal = null;

		Authority auth = new Authority();
		auth.setAuthority("STUDENT");
		if (LoginService.getPrincipal().getAuthorities().contains(auth)) {
			proposal = proposalService.create(subject);
		}

		res = new ModelAndView("tutorship/list");
		res.addObject("tutorships", tutorships);
		res.addObject("subject", subject);
		res.addObject("proposal", proposal);

		return res;

	}
}
