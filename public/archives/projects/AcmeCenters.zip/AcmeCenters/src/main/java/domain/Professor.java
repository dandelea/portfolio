package domain;

import java.util.Collection;
import java.util.HashSet;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Access(AccessType.PROPERTY)
public class Professor extends Actor {
	private String curriculum;
	private Collection<Membership> memberships;

	public Professor() {
		super();
		this.memberships = new HashSet<Membership>();
	}

	@NotNull
	@NotBlank
	public String getCurriculum() {
		return curriculum;
	}

	public void setCurriculum(String curriculum) {
		this.curriculum = curriculum;
	}

	// Relations

	@NotNull
	@Valid
	@OneToMany(mappedBy = "professor")
	public Collection<Membership> getMemberships() {
		return memberships;
	}

	public void setMemberships(Collection<Membership> memberships) {
		this.memberships = memberships;
	}
}
