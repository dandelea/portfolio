package services;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import repositories.ProposalRepository;
import security.LoginService;
import security.UserAccount;
import domain.Actor;
import domain.Notification;
import domain.NotificationType;
import domain.Professor;
import domain.Proposal;
import domain.Student;
import domain.Subject;
import domain.Tutorship;
import domain.WeekDay;

@Service
@Transactional
public class ProposalService {

	// Managed repository
	@Autowired
	private ProposalRepository proposalRepository;

	// Support services
	@Autowired
	private ProfessorService professorService;
	@Autowired
	private StudentService studentService;
	@Autowired
	private SubjectService subjectService;
	@Autowired
	private TutorshipService tutorshipService;
	@Autowired
	private NotificationService notificationService;

	// CRUD methods

	public Proposal findOne(int proposalId) {
		return proposalRepository.findOne(proposalId);
	}

	// Business methods
	public Collection<Proposal> findByPrincipalProfessorNotFinished() {
		Professor professor = professorService.findByPrincipal();
		return proposalRepository.findNotFinishedByProfessorId(professor
				.getId());
	}

	public Collection<Proposal> findByPrincipalProfessor() {
		Professor professor = professorService.findByPrincipal();
		return proposalRepository.findByProfessorId(professor.getId());
	}

	public Collection<Proposal> findByStudent(Student student) {
		Assert.notNull(student);
		return proposalRepository.findByStudentId(student.getId());
	}

	public Collection<Proposal> findByPrincipalStudentNotFinished() {
		Student student = studentService.findByPrincipal();
		return proposalRepository.findNotFinishedByStudentId(student.getId());
	}

	@SuppressWarnings("deprecation")
	public Proposal accept(Proposal proposal) {
		Assert.notNull(proposal);
		checkIsPrincipal(proposal.getSubject().getMembership().getProfessor());
		proposal.setAccepted(true);

		// Notificar que ha sido aceptada
		Student student = proposal.getStudent();
		Notification notification = notificationService.create(student);
		notification.setNotificationType(NotificationType.ACCEPTED_PROPOSAL);
		
		//Datos de la notificaci�n: nombre de la asignatura y fecha propuesta
		List<String> data = new ArrayList<String>();
		data.add(proposal.getSubject().getName());
		data.add(proposal.getProposedDate().toLocaleString());
		notification.setData(data);
		notificationService.save(notification);

		return proposalRepository.save(proposal);
	}

	@SuppressWarnings("deprecation")
	public Proposal decline(Proposal proposal) {
		Assert.notNull(proposal);
		checkIsPrincipal(proposal.getSubject().getMembership().getProfessor());
		proposal.setAccepted(false);

		// Notificar que ha sido denegada
		Student student = proposal.getStudent();
		Notification notification = notificationService.create(student);
		notification.setNotificationType(NotificationType.DENIED_PROPOSAL);
		
		//Datos de la notificaci�n: nombre de la asignatura y fecha propuesta
		List<String> data = new ArrayList<String>();
		data.add(proposal.getSubject().getName());
		data.add(proposal.getProposedDate().toLocaleString());
		notification.setData(data);
		notificationService.save(notification);

		return proposalRepository.save(proposal);
	}

	public Proposal create(Subject subject) {
		Assert.notNull(subject);
		Assert.isTrue(subjectService.findByStudent(
				studentService.findByPrincipal()).contains(subject));
		Proposal proposal = new Proposal();
		proposal.setStudent(studentService.findByPrincipal());
		proposal.setSubject(subject);
		return proposal;
	}

	public Proposal save(Proposal proposal) {
		Assert.notNull(proposal);
		checkIsPrincipal(proposal.getStudent());
		Assert.isTrue(subjectService.findByStudent(
				studentService.findByPrincipal()).contains(
				proposal.getSubject()));
		//Comprueba que la fecha propuesta es futura
		Assert.isTrue(proposal.getProposedDate().after(new Date()));
		//Comprueba que se ha propuesto una fecha dentro de los horarios de tutor�as
		checkCorrectProposal(proposal.getProposedDate(), proposal.getSubject());
		return proposalRepository.save(proposal);
	}

	private void checkCorrectProposal(Date proposedDate, Subject subject) {
		WeekDay weekDay = dayOfWeek(proposedDate);
		Collection<Tutorship> tutorships = tutorshipService
				.findBySubject(subject);
		boolean anyCorrect = false;
		
		//Comprueba que la fecha propuesta est� dentro de alguno de los intervalos horarios de la asignatura
		for (Tutorship tutorship : tutorships) {
			anyCorrect = anyCorrect
					//Para que pertenezca al intervalo, el d�a de la semana debe ser el mismo y la hora debe de estar entre las dos del intervalo
					|| (dateTimeInRange(tutorship.getStartTime(), proposedDate,
							tutorship.getEndTime()) && tutorship.getWeekDay()
							.equals(weekDay));
		}
		Assert.isTrue(anyCorrect);
	}

	//M�todo usado para comprar fechas a nivel de horas y minutos
	@SuppressWarnings("deprecation")
	private boolean dateTimeInRange(Date d1, Date d2, Date d3) {
		// d2 > d1
		boolean aux1 = d2.getHours() > d1.getHours();
		if (d2.getHours() == d1.getHours()) {
			aux1 = d2.getMinutes() >= d1.getMinutes();
		}
		// d2 < d3
		boolean aux2 = d2.getHours() < d3.getHours();
		if (d2.getHours() == d3.getHours()) {
			aux2 = d2.getMinutes() < d3.getMinutes();
		}
		return aux1 && aux2;
	}

	//M�todo usado para transformar el d�a de la semana del horario de tutor�as en un d�a de la semana usado por Calendar
	private WeekDay dayOfWeek(Date date) {
		WeekDay result = null;
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY) {
			result = WeekDay.MONDAY;
		} else if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.TUESDAY) {
			result = WeekDay.TUESDAY;
		} else if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.WEDNESDAY) {
			result = WeekDay.WEDNESDAY;
		} else if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.THURSDAY) {
			result = WeekDay.THURSDAY;
		} else if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY) {
			result = WeekDay.FRIDAY;
		} else if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
			result = WeekDay.SATURDAY;
		} else if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
			result = WeekDay.SUNDAY;
		}
		return result;
	}

	public void checkIsPrincipal(Actor a) {
		UserAccount principal = LoginService.getPrincipal();
		Assert.isTrue(principal.equals(a.getUserAccount()));
	}

}
