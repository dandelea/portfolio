package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Evaluation;

@Repository
public interface EvaluationRepository extends
		JpaRepository<Evaluation, Integer> {

	@Query("select e from Evaluation e where e.subject.id=?1")
	public Collection<Evaluation> findBySubjectId(int id);

	// Se seleccionan las evaluaciones de una asignatura en las que no est�
	// registrado un estudiante (no exista un evaluatedStudent para el
	// estudiante y la asignatura)
	@Query("select e from Evaluation e where e.subject.id=?1 and e.finishDate>CURRENT_DATE and not exists (select a from EvaluatedStudent a where a.evaluation.id=e.id and a.registration.student.id=?2)")
	public Collection<Evaluation> findNotRegisteredBySubjectId(int subjectId,
			int studentId);

	@Query("select e.evaluation from EvaluatedStudent e where e.registration.student.id=?1 and e.evaluation.finishDate>CURRENT_DATE")
	public Collection<Evaluation> findRegisteredNotFinished(int studentId);

	@Query("select e.evaluation from EvaluatedStudent e where e.registration.student.id=?1")
	public Collection<Evaluation> findRegisteredByStudentId(int id);

}
