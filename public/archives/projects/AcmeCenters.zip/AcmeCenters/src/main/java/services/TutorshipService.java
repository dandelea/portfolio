package services;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import repositories.TutorshipRepository;
import domain.Actor;
import domain.Professor;
import domain.Student;
import domain.Subject;
import domain.Tutorship;

@Service
@Transactional
public class TutorshipService {

	// Managed repository
	@Autowired
	private TutorshipRepository tutorshipRepository;

	// Support services
	@Autowired
	private ProfessorService professorService;
	@Autowired
	private StudentService studentService;
	@Autowired
	private ActorService actorService;
	@Autowired
	private SubjectService subjectService;

	// CRUD methods
	public Tutorship findOne(int tutorshipId) {
		return tutorshipRepository.findOne(tutorshipId);
	}

	// Business methods
	public Collection<Tutorship> findBySubject(Subject subject) {
		Assert.notNull(subject);
		checkPrincipalBelongsToSubject(subject);
		return tutorshipRepository.findBySubjectId(subject.getId());
	}

	public Tutorship create(Subject subject) {
		Assert.notNull(subject);
		checkPrincipalBelongsToSubject(subject);
		Tutorship tutorship = new Tutorship();
		tutorship.setSubject(subject);
		return tutorship;
	}

	public Tutorship save(Tutorship tutorship) {
		Assert.notNull(tutorship);
		Assert.isTrue(professorService.findByPrincipal().equals(
				tutorship.getSubject().getMembership().getProfessor()));
		Assert.isTrue(tutorship.getStartTime().before(tutorship.getEndTime()));
		return tutorshipRepository.save(tutorship);

	}

	public void delete(Tutorship tutorship) {
		Assert.notNull(tutorship);
		Assert.isTrue(professorService.findByPrincipal().equals(
				tutorship.getSubject().getMembership().getProfessor()));
		// TODO NOTIFICACION ELIMINACION DE TUTORIA
		tutorshipRepository.delete(tutorship);
	}

	private void checkPrincipalBelongsToSubject(Subject subject) {
		Actor a = actorService.findByPrincipal();
		if (a instanceof Student) {
			Student student = studentService.findByPrincipal();
			Assert.isTrue(subjectService.findByStudent(student).contains(
					subject));
		} else if (a instanceof Professor) {
			Professor professor = professorService.findByPrincipal();
			Assert.isTrue(subject.getMembership().getProfessor()
					.equals(professor));
		}
	}

}
