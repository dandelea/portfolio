package services;

import java.io.IOException;
import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import repositories.ProfessorRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import domain.Center;
import domain.Professor;
import domain.Student;
import forms.ProfessorEditForm;
import forms.ProfessorForm;
import forms.ProfessorSearchForm;

@Service
@Transactional
public class ProfessorService {

	// Managed repository
	@Autowired
	private ProfessorRepository professorRepository;

	public Professor findOne(int professorId) {
		return professorRepository.findOne(professorId);
	}

	public Professor findByUserAccountId(int id) {
		Authority auth = new Authority();
		auth.setAuthority("PROFESSOR");
		Assert.isTrue(LoginService.getPrincipal().getAuthorities()
				.contains(auth));
		Professor c = professorRepository.findByUserAccountId(id);
		return c;
	}

	public Collection<Professor> findProfessorsByCenter(Center center) {
		Assert.notNull(center);
		Collection<Professor> c;
		c = professorRepository.findProfessorsByCenterId(center.getId());
		return c;
	}

	public Collection<Professor> findProfessorsByStudent(Student s) {
		Assert.notNull(s);
		return professorRepository.findProfessorsByStudentId(s.getId());
	}

	//Crea una petici�n indicando c�mo deben de ser los campos. Los "%" indican que solo debe de estar contenida la String indicada por el usuario
	public Collection<Professor> search(ProfessorSearchForm professorSearchForm) {
		Assert.notNull(professorSearchForm);
		return professorRepository.searchProfessors(
				"%" + professorSearchForm.getName() + "%", "%"
						+ professorSearchForm.getSurnames() + "%", "%"
						+ professorSearchForm.getEmail() + "%", "%"
						+ professorSearchForm.getCurriculum() + "%");
	}

	public Professor findByPrincipal() {
		UserAccount principal = LoginService.getPrincipal();
		return findByUserAccountId(principal.getId());
	}

	public Professor create() {
		Professor professor = new Professor();
		Authority authority = new Authority();
		authority.setAuthority("PROFESSOR");
		UserAccount userAccount = new UserAccount();
		userAccount.addAuthority(authority);
		professor.setUserAccount(userAccount);

		return professor;
	}

	public Professor save(Professor p) {
		Assert.notNull(p);
		Assert.isTrue(findByPrincipal().equals(p));
		return professorRepository.save(p);
	}

	public Professor register(Professor professor) {
		Assert.notNull(professor);
		Md5PasswordEncoder encoder = new Md5PasswordEncoder();
		String password = professor.getUserAccount().getPassword();
		String username = professor.getUserAccount().getUsername();
		Assert.isTrue(password.length() >= 5 && password.length() <= 32);
		Assert.isTrue(username.length() >= 5 && username.length() <= 32);
		professor.getUserAccount().setPassword(
				encoder.encodePassword(password, null));
		return professorRepository.save(professor);
	}

	public Professor reconstruct(ProfessorForm professorForm) {
		Assert.notNull(professorForm);
		Professor professor = create();
		Assert.isTrue(professorForm.getPassword().equals(
				professorForm.getPassword2()));
		Assert.isTrue(professorForm.getPicture().getContentType()
				.equals(("image/jpeg")));

		professor.getUserAccount().setUsername(professorForm.getUsername());
		professor.getUserAccount().setPassword(professorForm.getPassword());
		professor.setEmail(professorForm.getEmail());
		professor.setName(professorForm.getName());
		professor.setSurname(professorForm.getSurnames());
		professor.setCurriculum(professorForm.getCurriculum());

		try {
			professor.setPicture(professorForm.getPicture().getBytes().clone());
		} catch (IOException e) {

			e.printStackTrace();

		}

		return professor;
	}

	public void checkIsProfessor() {
		Authority professor = new Authority();
		professor.setAuthority("PROFESSOR");
		Assert.isTrue(LoginService.getPrincipal().getAuthorities()
				.contains(professor));
	}

	public ProfessorEditForm edit(Professor s) {
		Assert.notNull(s);
		ProfessorEditForm seForm = new ProfessorEditForm();
		seForm.setEmail(s.getEmail());
		seForm.setName(s.getName());
		seForm.setSurnames(s.getSurname());
		seForm.setCurriculum(s.getCurriculum());

		return seForm;
	}

	public Professor reconstructEdit(ProfessorEditForm pEditForm) {
		Assert.notNull(pEditForm);
		Professor p = findByPrincipal();
		Assert.isTrue(pEditForm.getPicture().getContentType()
				.equals(("image/jpeg")));
		p.setEmail(pEditForm.getEmail());
		p.setName(pEditForm.getName());
		p.setSurname(pEditForm.getSurnames());
		p.setCurriculum(pEditForm.getCurriculum());
		try {
			p.setPicture(pEditForm.getPicture().getBytes().clone());
		} catch (IOException e) {
			e.printStackTrace();
		}

		return p;
	}

}
