package controllers.student;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.RegistrationService;
import controllers.AbstractController;
import domain.Registration;

@Controller
@RequestMapping("/registration/student")
public class RegistrationStudentController extends AbstractController {

	@Autowired
	private RegistrationService registrationService;

	// Constructors -----------------------------------------------------------

	public RegistrationStudentController() {
		super();
	}

	@RequestMapping(value = "/listMine", method = RequestMethod.GET)
	public ModelAndView listMine() {
		ModelAndView result;

		Collection<Registration> registrations = registrationService
				.findByPrincipal();

		result = new ModelAndView("registration/list");
		result.addObject("registrations", registrations);
		result.addObject("requestURI", "registration/student/listMine.do");

		return result;
	}

}
