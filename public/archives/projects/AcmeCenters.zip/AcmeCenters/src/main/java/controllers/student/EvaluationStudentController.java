package controllers.student;

import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.EvaluatedStudentService;
import services.EvaluationService;
import services.SubjectService;
import controllers.AbstractController;
import domain.Evaluation;
import domain.Subject;

@Controller
@RequestMapping("/evaluation/student")
public class EvaluationStudentController extends AbstractController {

	// Support services
	@Autowired
	private EvaluationService evaluationService;

	@Autowired
	private SubjectService subjectService;

	@Autowired
	private EvaluatedStudentService evaluatedStudentService;

	// Constructor
	public EvaluationStudentController() {
		super();
	}

	// List methods

	@RequestMapping(value = "/listNotRegistered", method = RequestMethod.GET)
	public ModelAndView listNotRegistered(@RequestParam int subjectId) {
		ModelAndView result;
		Subject subject = subjectService.findOne(subjectId);
		Collection<Evaluation> evaluations;
		String requestURI;

		evaluations = evaluationService.findNotRegisteredBySubject(subject);
		requestURI = "evaluation/student/listNotRegistered.do?subjectId="
				+ subjectId;
		boolean isAvailable = subject.getRegistrationLimit().before(new Date());

		result = new ModelAndView("evaluation/list");
		result.addObject("evaluations", evaluations);
		result.addObject("requestURI", requestURI);
		result.addObject("isAvailable", isAvailable);

		return result;
	}

	@RequestMapping(value = "/listRegisteredNotFinished", method = RequestMethod.GET)
	public ModelAndView listRegisteredNotFinished() {
		ModelAndView result;
		Collection<Evaluation> evaluations;
		String requestURI;

		evaluations = evaluationService.findRegisteredNotFinished();
		requestURI = "evaluation/student/listRegisteredNotFinished.do";
		boolean isAvailable = false;

		result = new ModelAndView("evaluation/list");
		result.addObject("evaluations", evaluations);
		result.addObject("requestURI", requestURI);
		result.addObject("isAvailable", isAvailable);

		return result;
	}

	// Register

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView register(@RequestParam int evaluationId) {
		ModelAndView result;
		Evaluation evaluation = evaluationService.findOne(evaluationId);
		try {
			evaluatedStudentService.register(evaluation);
			result = listRegisteredNotFinished();
		} catch (Throwable oops) {
			result = new ModelAndView(
					"redirect:../../evaluation/display.do?evaluationId="
							+ evaluation.getId());
			result.addObject("message", "evaluation.commit.error");
		}
		return result;
	}
}
