package domain;

import java.util.Collection;
import java.util.HashSet;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Entity
@Access(AccessType.PROPERTY)
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "center_id",
		"professor_id" }))
public class Membership extends DomainEntity {
	private Professor professor;
	private Center center;
	private Collection<Subject> subjects;

	public Membership() {
		super();
		this.subjects = new HashSet<Subject>();
	}

	// Relations

	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Professor getProfessor() {
		return professor;
	}

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}

	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Center getCenter() {
		return center;
	}

	public void setCenter(Center center) {
		this.center = center;
	}

	@NotNull
	@Valid
	@OneToMany(mappedBy = "membership")
	public Collection<Subject> getSubjects() {
		return subjects;
	}

	public void setSubjects(Collection<Subject> subjects) {
		this.subjects = subjects;
	}

}
