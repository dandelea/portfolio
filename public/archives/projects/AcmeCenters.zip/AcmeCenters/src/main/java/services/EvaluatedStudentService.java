package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import repositories.EvaluatedStudentRepository;
import security.LoginService;
import security.UserAccount;
import domain.Actor;
import domain.EvaluatedStudent;
import domain.Evaluation;
import domain.Notification;
import domain.NotificationType;
import domain.Registration;
import domain.Student;
import domain.Subject;

@Service
@Transactional
public class EvaluatedStudentService {

	// Managed repository
	@Autowired
	private EvaluatedStudentRepository evaluatedStudentRepository;

	// Support services
	@Autowired
	private SubjectService subjectService;
	@Autowired
	private StudentService studentService;
	@Autowired
	private RegistrationService registrationService;
	@Autowired
	private NotificationService notificationService;

	public EvaluatedStudent findOne(int evaluatedStudentId) {
		return evaluatedStudentRepository.findOne(evaluatedStudentId);
	}

	public Collection<EvaluatedStudent> findByEvaluation(Evaluation evaluation) {
		Assert.notNull(evaluation);
		return evaluatedStudentRepository
				.findByEvaluationId(evaluation.getId());
	}

	public Collection<EvaluatedStudent> findFinishedByStudent(Student student) {
		Assert.notNull(student);
		checkIsPrincipal(student);
		return evaluatedStudentRepository.findFinishedByStudentId(student
				.getId());
	}

	public Collection<EvaluatedStudent> findByRegistration(
			Registration registration) {
		Assert.notNull(registration);
		return evaluatedStudentRepository.findByRegistrationId(registration
				.getId());
	}

	public Collection<EvaluatedStudent> findBySubjectForPrincipalStudent(
			Subject subject) {
		Assert.notNull(subject);
		Student student = studentService.findByPrincipal();
		return evaluatedStudentRepository.findBySubjectIdAndStudentId(
				subject.getId(), student.getId());
	}

	public EvaluatedStudent register(Evaluation evaluation) {
		Assert.notNull(evaluation);
		Student student = studentService.findByPrincipal();
		Collection<Subject> subjects = subjectService.findByStudent(student);

		// Comprueba que el estudiante est� registrado en la asignatura de la
		// evaluaci�n
		Assert.isTrue(subjects.contains(evaluation.getSubject()));


		// Comprueba que no ha pasado la fecha l�mite de la evaluaci�n
		Assert.isTrue(evaluation.getFinishDate().after(new Date()));
		EvaluatedStudent e = new EvaluatedStudent();
		e.setEvaluation(evaluation);
		Registration registration = registrationService
				.findBySubjectForPrincipal(evaluation.getSubject());
		e.setRegistration(registration);
		return evaluatedStudentRepository.save(e);
	}

	public void registerObligatoryEvaluation(Evaluation evaluation) {
		Assert.notNull(evaluation);
		Assert.isTrue(evaluation.getFinishDate().after(new Date()));
		Collection<Registration> registrations = registrationService
				.findBySubject(evaluation.getSubject());
		// Registra a todos los usuarios de la asignatura
		for (Registration registration : registrations) {
			EvaluatedStudent evaluatedStudent = new EvaluatedStudent();
			evaluatedStudent.setEvaluation(evaluation);
			evaluatedStudent.setRegistration(registration);
			evaluatedStudentRepository.save(evaluatedStudent);
		}
	}

	// Solo usado por profesores al calificar
	public EvaluatedStudent save(EvaluatedStudent evaluatedStudent) {
		Assert.isTrue(evaluatedStudent.getEvaluation().getFinishDate()
				.before(new Date()));
		checkIsPrincipal(evaluatedStudent.getEvaluation().getSubject()
				.getMembership().getProfessor());
		EvaluatedStudent pastMark = findOne(evaluatedStudent.getId());
		EvaluatedStudent result = evaluatedStudentRepository
				.save(evaluatedStudent);

		// Calcula nueva nota final
		registrationService.updateFinalMarks(result.getRegistration());

		// Notificar al alumno:
		NotificationType notificationType = null;
		// Caso 1: Nueva nota.
		if (pastMark.getMark()==null) {
			notificationType = NotificationType.NEW_MARK;
		} else {
			// Caso 2: Nota cambiada.
			notificationType = NotificationType.CHANGED_MARK;
		}
		Notification notification = notificationService.create(evaluatedStudent
				.getRegistration().getStudent());
		notification.setNotificationType(notificationType);

		// Datos de la notificaci�n: nombre de la evaluaci�n y nota nueva
		List<String> data = new ArrayList<String>();
		data.add(evaluatedStudent.getMark().toString());
		data.add(evaluatedStudent.getEvaluation().getName());
		notification.setData(data);
		notificationService.save(notification);

		return result;
	}

	public void checkIsPrincipal(Actor a) {
		UserAccount principal = LoginService.getPrincipal();
		Assert.isTrue(principal.equals(a.getUserAccount()));
	}
}
