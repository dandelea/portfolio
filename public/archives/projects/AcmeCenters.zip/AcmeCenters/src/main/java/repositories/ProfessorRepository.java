package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Professor;

@Repository
public interface ProfessorRepository extends JpaRepository<Professor, Integer> {

	@Query("select p from Professor p where p.userAccount.id=?1")
	public Professor findByUserAccountId(int id);

	@Query("select b.professor from Membership b where b.center.id=?1")
	public Collection<Professor> findProfessorsByCenterId(int id);

	@Query("select distinct r.subject.membership.professor from Registration r where r.student.id=?1")
	public Collection<Professor> findProfessorsByStudentId(int id);

	// Se seleccionan los profesores que contienen en los valores de sus
	// atributos los valores introducidos
	@Query("select p from Professor p where p.name like ?1 and p.surname like ?2 and p.email like ?3 and p.curriculum like ?4")
	public Collection<Professor> searchProfessors(String name, String surnames,
			String email, String curriculum);
}
