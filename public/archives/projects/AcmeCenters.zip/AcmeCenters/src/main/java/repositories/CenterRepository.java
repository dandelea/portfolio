package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Center;

@Repository
public interface CenterRepository extends JpaRepository<Center, Integer> {

	// Se seleccionan los centros que contienen en los valores de sus atributos
	// los valores introducidos
	@Query("select c from Center c where c.code like ?1 and c.description like ?2 and c.name like ?3 and c.postalCode like ?4 and c.address like ?5")
	public Collection<Center> searchCenters(String code, String description,
			String name, String postalCode, String address);

	@Query("select b.center from Membership b where b.professor.id=?1")
	public Collection<Center> findByProfessorId(int professorId);

	@Query("select distinct r.subject.membership.center from Registration r where r.student.id=?1")
	public Collection<Center> findByStudentId(int studentId);
}
