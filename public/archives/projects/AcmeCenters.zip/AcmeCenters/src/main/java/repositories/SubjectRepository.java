package repositories;

import java.util.Collection;
import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Subject;

@Repository
public interface SubjectRepository extends JpaRepository<Subject, Integer> {

	@Query("select r.subject from Registration r where r.student.id=?1")
	Collection<Subject> findByStudentId(int studentId);

	@Query("select s from Subject s where s.membership.center.id=?1")
	Collection<Subject> findByCenterId(int centerId);

	//Se seleccionan las asignaturas de un centro cuya fecha l�mite no ha pasado y cuyo n� m�ximo de alumnos no se ha alcanzado.
	@Query("select s from Subject s where s.membership.center.id=?1 and s.registrationLimit>?2 and s.numberStudents<s.maximumNumberStudents")
	Collection<Subject> findAvailableByCenterId(int centerId, Date date);

	@Query("select s from Subject s where s.membership.professor.id=?1")
	Collection<Subject> findByProfessorId(int professorId);

	@Query("select s from Subject s where s.membership.center.id=?1 and s.membership.professor.id=?2")
	Collection<Subject> findByCenterIdAndProfessorId(int centerId,
			int professorId);
}
