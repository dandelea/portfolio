package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Registration;

@Repository
public interface RegistrationRepository extends
		JpaRepository<Registration, Integer> {

	@Query("select r from Registration r where r.student.id=?1 and r.subject.id=?2")
	public Registration findByStudentIdSubjectId(int studentId, int subjectId);

	@Query("select r from Registration r where r.subject.id=?1")
	public Collection<Registration> findBySubjectId(int subjectId);

	@Query("select r from Registration r where r.student.id=?1")
	public Collection<Registration> findByStudentId(int StudentId);

	@Query("select SUM(e.mark*e.evaluation.weighting) from EvaluatedStudent e where e.registration.id=?1")
	public Double calculateFinalMark(int registrationId);
}
