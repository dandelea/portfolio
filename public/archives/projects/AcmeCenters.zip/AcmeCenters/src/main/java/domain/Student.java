package domain;

import java.util.Collection;
import java.util.HashSet;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Access(AccessType.PROPERTY)
public class Student extends Actor {
	private String phone, nameAndSurnamesFather, nameAndSurnamesMother,
			interests, illnessesAndDissabilities, address;
	private Collection<Notification> notifications;
	private Collection<Registration> registrations;
	private Collection<Proposal> proposals;

	public Student() {
		super();
		this.notifications = new HashSet<Notification>();
		this.registrations = new HashSet<Registration>();
		this.proposals = new HashSet<Proposal>();
	}

	@NotNull
	@NotBlank
	@Pattern(regexp = "\\d{9}")
	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@NotNull
	@NotBlank
	public String getNameAndSurnamesFather() {
		return nameAndSurnamesFather;
	}

	public void setNameAndSurnamesFather(String nameAndSurnamesFather) {
		this.nameAndSurnamesFather = nameAndSurnamesFather;
	}

	@NotNull
	@NotBlank
	public String getNameAndSurnamesMother() {
		return nameAndSurnamesMother;
	}

	public void setNameAndSurnamesMother(String nameAndSurnamesMother) {
		this.nameAndSurnamesMother = nameAndSurnamesMother;
	}

	@NotNull
	@NotBlank
	public String getInterests() {
		return interests;
	}

	public void setInterests(String interests) {
		this.interests = interests;
	}

	@NotNull
	public String getIllnessesAndDissabilities() {
		return illnessesAndDissabilities;
	}

	public void setIllnessesAndDissabilities(String illnessesAndDissabilities) {
		this.illnessesAndDissabilities = illnessesAndDissabilities;
	}

	@NotNull
	@NotBlank
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	// Relations

	@NotNull
	@Valid
	@OneToMany(mappedBy = "student")
	public Collection<Notification> getNotifications() {
		return notifications;
	}

	public void setNotifications(Collection<Notification> notifications) {
		this.notifications = notifications;
	}

	@NotNull
	@Valid
	@OneToMany(mappedBy = "student")
	public Collection<Registration> getRegistrations() {
		return registrations;
	}

	public void setRegistrations(Collection<Registration> registrations) {
		this.registrations = registrations;
	}

	@NotNull
	@Valid
	@OneToMany(mappedBy = "student")
	public Collection<Proposal> getProposals() {
		return proposals;
	}

	public void setProposals(Collection<Proposal> proposals) {
		this.proposals = proposals;
	}

}
