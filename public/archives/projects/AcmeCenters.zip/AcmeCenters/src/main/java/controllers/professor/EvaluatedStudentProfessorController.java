package controllers.professor;

import java.util.Date;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.EvaluatedStudentService;
import services.EvaluationService;
import controllers.AbstractController;
import domain.EvaluatedStudent;
import domain.Evaluation;

@Controller
@RequestMapping("/evaluatedStudent/professor")
public class EvaluatedStudentProfessorController extends AbstractController {

	// Support services
	@Autowired
	private EvaluatedStudentService evaluatedStudentService;
	@Autowired
	private EvaluationService evaluationService;

	// Constructor
	public EvaluatedStudentProfessorController() {
		super();
	}

	// List

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam int evaluationId) {
		ModelAndView result;
		Evaluation evaluation = evaluationService.findOne(evaluationId);
		Collection<EvaluatedStudent> evaluatedStudents = evaluatedStudentService
				.findByEvaluation(evaluation);
		Date today = new Date();
		boolean finished = today.after(evaluation.getFinishDate());
		String requestURI = "evaluatedStudent/professor/list.do?evaluationId="
				+ evaluationId;
		result = new ModelAndView("evaluatedStudent/list");
		result.addObject("evaluatedStudents", evaluatedStudents);
		result.addObject("finished", finished);
		result.addObject("requestURI", requestURI);
		return result;
	}

	// Edition
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam int evaluatedStudentId) {
		EvaluatedStudent evaluatedStudent = evaluatedStudentService
				.findOne(evaluatedStudentId);
		return createEditModelAndView(evaluatedStudent);
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid EvaluatedStudent evaluatedStudent,
			BindingResult binding) {
		ModelAndView res;
		if (binding.hasErrors()) {
			res = createEditModelAndView(evaluatedStudent);
		} else {
			try {
				evaluatedStudentService.save(evaluatedStudent);
				res = list(evaluatedStudent.getEvaluation().getId());
			} catch (Throwable oops) {
				res = createEditModelAndView(evaluatedStudent,
						"evaluation.commit.error");
			}
		}
		return res;
	}

	public ModelAndView createEditModelAndView(EvaluatedStudent evaluatedStudent) {
		return createEditModelAndView(evaluatedStudent, null);
	}

	public ModelAndView createEditModelAndView(
			EvaluatedStudent evaluatedStudent, String message) {
		ModelAndView result = new ModelAndView("evaluatedStudent/edit");
		result.addObject("evaluatedStudent", evaluatedStudent);
		result.addObject("message", message);
		return result;
	}

}
