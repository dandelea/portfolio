package controllers.student;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.CenterService;
import controllers.AbstractController;
import domain.Center;

@Controller
@RequestMapping("/center/student")
public class CenterStudentController extends AbstractController {

	@Autowired
	private CenterService centerService;

	// Constructors -----------------------------------------------------------

	public CenterStudentController() {
		super();
	}

	@RequestMapping(value = "/listMine", method = RequestMethod.GET)
	public ModelAndView listMine() {
		ModelAndView result;

		Collection<Center> centers = centerService.findByPrincipalStudent();

		result = new ModelAndView("center/list");
		result.addObject("centers", centers);

		return result;
	}

}
