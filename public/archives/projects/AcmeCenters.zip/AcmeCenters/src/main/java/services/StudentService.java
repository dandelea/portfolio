package services;

import java.io.IOException;
import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import repositories.StudentRepository;
import security.Authority;
import security.LoginService;
import security.UserAccount;
import domain.Professor;
import domain.Student;
import domain.Subject;
import forms.StudentEditForm;
import forms.StudentForm;

@Service
@Transactional
public class StudentService {

	// Managed repository
	@Autowired
	private StudentRepository studentRepository;

	// Support services
	@Autowired
	private ProfessorService professorService;

	public Student findOne(int studentId) {
		Student student = studentRepository.findOne(studentId);
		// Comprobar que puede acceder a esta informacion
		Authority studentAuth = new Authority();
		studentAuth.setAuthority("STUDENT");
		Authority professorAuth = new Authority();
		professorAuth.setAuthority("PROFESSOR");
		// Si es profesor
		if (LoginService.getPrincipal().getAuthorities()
				.contains(professorAuth)) {
			boolean any = false;
			for (Professor professor : professorService
					.findProfessorsByStudent(student)) {
				any = any
						|| professor.equals(professorService.findByPrincipal());
			}
			// El alumno pertenece a alguna de las asignatuas que imparte
			Assert.isTrue(any);
			// Si es un alumno
		} else if (LoginService.getPrincipal().getAuthorities()
				.contains(studentAuth)) {
			// Debe ser �l mismo
			Assert.isTrue(findByPrincipal().equals(student));
		}
		return student;
	}

	public Student findByUserAccountId(int id) {
		Authority auth = new Authority();
		auth.setAuthority("STUDENT");
		Assert.isTrue(LoginService.getPrincipal().getAuthorities()
				.contains(auth));
		Student c = studentRepository.findByUserAccountId(id);
		return c;
	}

	public Student findByPrincipal() {
		UserAccount principal = LoginService.getPrincipal();
		return findByUserAccountId(principal.getId());
	}

	public Collection<Student> findBySubject(Subject subject) {
		Assert.notNull(subject);
		return studentRepository.findBySubjectId(subject.getId());
	}

	public Student create() {
		Student student = new Student();
		Authority authority = new Authority();
		authority.setAuthority("STUDENT");
		UserAccount userAccount = new UserAccount();
		userAccount.addAuthority(authority);
		student.setUserAccount(userAccount);

		return student;
	}

	public Student save(Student s) {
		Assert.notNull(s);
		return studentRepository.save(s);
	}

	public Student register(Student student) {
		Assert.notNull(student);
		Md5PasswordEncoder encoder = new Md5PasswordEncoder();
		String password = student.getUserAccount().getPassword();
		String username = student.getUserAccount().getUsername();
		Assert.isTrue(password.length() >= 5 && password.length() <= 32);
		Assert.isTrue(username.length() >= 5 && username.length() <= 32);
		student.getUserAccount().setPassword(
				encoder.encodePassword(password, null));
		return studentRepository.save(student);
	}

	public Student reconstruct(StudentForm studentForm) {
		Student student = create();
		Assert.isTrue(studentForm.getPassword().equals(
				studentForm.getPassword2()));
		Assert.isTrue(studentForm.getPicture().getContentType()
				.equals(("image/jpeg")));

		student.getUserAccount().setUsername(studentForm.getUsername());
		student.getUserAccount().setPassword(studentForm.getPassword());
		student.setEmail(studentForm.getEmail());
		student.setName(studentForm.getName());
		student.setSurname(studentForm.getSurnames());
		student.setAddress(studentForm.getAddress());
		student.setIllnessesAndDissabilities(studentForm
				.getIllnessesAndDissabilities());
		student.setInterests(studentForm.getInterests());
		student.setNameAndSurnamesFather(studentForm.getNameAndSurnamesFather());
		student.setNameAndSurnamesMother(studentForm.getNameAndSurnamesMother());
		student.setPhone(studentForm.getPhone());
		try {
			student.setPicture(studentForm.getPicture().getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}

		return student;
	}

	public void checkIsAlum() {
		Authority student = new Authority();
		student.setAuthority("STUDENT");
		Assert.isTrue(LoginService.getPrincipal().getAuthorities()
				.contains(student));
	}

	public StudentEditForm edit(Student s) {
		StudentEditForm seForm = new StudentEditForm();
		seForm.setAddress(s.getAddress());
		seForm.setEmail(s.getEmail());
		seForm.setIllnessesAndDissabilities(s.getIllnessesAndDissabilities());
		seForm.setInterests(s.getInterests());
		seForm.setName(s.getName());
		seForm.setNameAndSurnamesFather(s.getNameAndSurnamesFather());
		seForm.setNameAndSurnamesMother(s.getNameAndSurnamesMother());
		seForm.setPhone(s.getPhone());
		seForm.setSurnames(s.getSurname());

		return seForm;
	}

	public Student reconstructEdit(StudentEditForm studentEditForm) {
		Student student = findByPrincipal();
		Assert.isTrue(studentEditForm.getPicture().getContentType()
				.equals(("image/jpeg")));
		student.setEmail(studentEditForm.getEmail());
		student.setName(studentEditForm.getName());
		student.setSurname(studentEditForm.getSurnames());
		student.setAddress(studentEditForm.getAddress());
		student.setIllnessesAndDissabilities(studentEditForm
				.getIllnessesAndDissabilities());
		student.setInterests(studentEditForm.getInterests());
		student.setNameAndSurnamesFather(studentEditForm
				.getNameAndSurnamesFather());
		student.setNameAndSurnamesMother(studentEditForm
				.getNameAndSurnamesMother());
		student.setPhone(studentEditForm.getPhone());
		try {
			student.setPicture(studentEditForm.getPicture().getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}

		return student;
	}

}
