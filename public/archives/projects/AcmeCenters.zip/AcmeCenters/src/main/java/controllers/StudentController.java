package controllers;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.StudentService;
import domain.Student;
import forms.StudentForm;

@Controller
@RequestMapping("/student")
public class StudentController extends AbstractController {

	@Autowired
	private StudentService studentService;

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		StudentForm studentForm;

		studentForm = new StudentForm();

		result = createModelAndView(studentForm);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid StudentForm studentForm,
			BindingResult binding) {
		ModelAndView result;
		Student student;

		if (binding.hasErrors()) {
			result = createModelAndView(studentForm);
		} else {
			try {
				Assert.isTrue(studentForm.getAccept());
				student = studentService.reconstruct(studentForm);
				studentService.register(student);
				result = new ModelAndView("redirect:../welcome/index.do");
			} catch (Throwable oops) {
				result = createModelAndView(studentForm, "student.commit.error");
			}
		}
		return result;
	}

	@RequestMapping(value = "/picture", method = RequestMethod.GET)
	public void picture(HttpServletResponse res, @RequestParam int studentId) {

		Student student = studentService.findOne(studentId);

		res.setContentType("image/jpeg");

		byte[] picture = student.getPicture();

		InputStream in1 = new ByteArrayInputStream(picture);

		try {
			IOUtils.copy(in1, res.getOutputStream());

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private ModelAndView createModelAndView(StudentForm studentForm) {
		ModelAndView result;

		result = createModelAndView(studentForm, null);

		return result;
	}

	private ModelAndView createModelAndView(StudentForm studentForm,
			String message) {
		ModelAndView result;

		result = new ModelAndView("student/edit");
		result.addObject("studentForm", studentForm);
		result.addObject("message", message);

		return result;
	}

}
