package controllers.professor;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.RegistrationService;
import services.SubjectService;
import controllers.AbstractController;
import domain.Registration;
import domain.Subject;

@Controller
@RequestMapping("/registration/professor")
public class RegistrationProfessorController extends AbstractController {

	@Autowired
	private RegistrationService registrationService;

	@Autowired
	private SubjectService subjectService;

	// Constructors -----------------------------------------------------------

	public RegistrationProfessorController() {
		super();
	}

	@RequestMapping(value = "/listBySubject", method = RequestMethod.GET)
	public ModelAndView listMine(@RequestParam int subjectId) {
		ModelAndView result;
		Subject subject = subjectService.findOne(subjectId);

		Collection<Registration> registrations = registrationService
				.findBySubject(subject);

		result = new ModelAndView("registration/list");
		result.addObject("registrations", registrations);
		result.addObject("requestURI", "registration/professor/listBySubject.do");

		return result;
	}

}
