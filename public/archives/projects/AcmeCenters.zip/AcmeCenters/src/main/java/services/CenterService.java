package services;

import java.util.Collection;
import java.util.HashSet;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import repositories.CenterRepository;
import security.Authority;
import security.LoginService;
import domain.Student;
import domain.Center;
import domain.Location;
import domain.Professor;
import forms.CenterSearchForm;

@Service
@Transactional
public class CenterService {

	// Managed repository
	@Autowired
	private CenterRepository centerRepository;

	@Autowired
	private ProfessorService professorService;

	@Autowired
	private StudentService studentService;

	public Center findOne(int centerId) {
		Center center = centerRepository.findOne(centerId);
		Assert.notNull(center);
		return center;
	}

	public Collection<Center> findAll() {
		return centerRepository.findAll();
	}

	public Collection<Center> findByPrincipal() {
		Professor professor = professorService.findByPrincipal();
		return centerRepository.findByProfessorId(professor.getId());
	}

	public Collection<Center> findByPrincipalStudent() {
		Student student = studentService.findByPrincipal();
		return centerRepository.findByStudentId(student.getId());
	}

	//Crea una petici�n indicando c�mo deben de ser los campos. Los "%" indican que solo debe de estar contenida la String indicada por el usuario
	public Collection<Center> search(CenterSearchForm centerSearchForm) {
		Collection<Center> centers = centerRepository.searchCenters("%"
				+ centerSearchForm.getCode() + "%",
				"%" + centerSearchForm.getDescription() + "%", "%"
						+ centerSearchForm.getName() + "%", "%"
						+ centerSearchForm.getPostalCode() + "%", "%"
						+ centerSearchForm.getAddress() + "%");

		// Filtra manualmente los atributos que no pueden filtrarse en la query:
		// distancia a un lugar y dependencia
		if (centerSearchForm.getDependency() != null) {
			Collection<Center> centers2 = new HashSet<Center>();
			for (Center center : centers) {
				if (center.getDependency() == centerSearchForm.getDependency()) {
					centers2.add(center);
				}
			}
			centers = centers2;
		}

		if (centerSearchForm.getRadius() != null) {
			Location location = new Location();
			location.setLatitude(centerSearchForm.getLatitude());
			location.setLongitude(centerSearchForm.getLongitude());
			Collection<Center> centers3 = new HashSet<Center>();
			for (Center center : centers) {
				if (getDistance(center.getLocation(), location) <= centerSearchForm
						.getRadius()) {
					centers3.add(center);
				}
			}
			centers = centers3;
		}

		return centers;
	}

	public Center create() {
		Center center = new Center();
		return center;
	}

	public Center save(Center center) {
		checkIsProfessor();
		Assert.isTrue(!(center.getLocation().getLatitude() == 0.0 && center
				.getLocation().getLongitude() == 0.0));
		return centerRepository.save(center);
	}

	//Calcula la distancia entre 2 puntos teniendo en cuenta la curvatura de la Tierra, suponiendo que
	//esta es una esfera perfecta
	private Double getDistance(Location location1, Location location2) {
		Double res = null;
		Double l1, l2, dg;
		l1 = location1.getLatitude();
		l2 = location2.getLatitude();
		dg = location2.getLongitude() - location1.getLongitude();
		res = 1.852 * 60 * Math.acos(Math.sin(l1) * Math.sin(l2) + Math.cos(l1)
				* Math.cos(l2) * Math.cos(dg));
		return res;
	}

	public void checkIsProfessor() {
		Authority professor = new Authority();
		professor.setAuthority("PROFESSOR");
		Assert.isTrue(LoginService.getPrincipal().getAuthorities()
				.contains(professor));
	}
}
