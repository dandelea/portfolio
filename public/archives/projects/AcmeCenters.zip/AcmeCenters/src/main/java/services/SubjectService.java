package services;

import java.util.Collection;
import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import repositories.SubjectRepository;
import security.LoginService;
import security.UserAccount;
import domain.Actor;
import domain.Center;
import domain.Professor;
import domain.Student;
import domain.Subject;

@Service
@Transactional
public class SubjectService {

	// Managed repository
	@Autowired
	private SubjectRepository subjectRepository;

	@Autowired
	private ProfessorService professorService;

	// CRUD methods

	public Subject findOne(int subjectId) {
		return subjectRepository.findOne(subjectId);
	}

	public Subject create() {
		Subject subject = new Subject();
		return subject;
	}

	public Subject save(Subject subject) {
		Assert.notNull(subject);
		checkIsPrincipal(subject.getMembership().getProfessor());
		return subjectRepository.save(subject);
	}

	public Subject addStudent(Subject subject) {
		Assert.notNull(subject);
		Assert.isTrue(subject.getId() > 0);
		subject.setNumberStudents(subject.getNumberStudents() + 1);
		return subjectRepository.save(subject);
	}

	// Business methods
	public Collection<Subject> findByStudent(Student student) {
		Assert.notNull(student);
		checkIsPrincipal(student);
		return subjectRepository.findByStudentId(student.getId());
	}

	public Collection<Subject> findByCenter(Center center) {
		Assert.notNull(center);
		return subjectRepository.findByCenterId(center.getId());
	}

	public Collection<Subject> findByCenterAndPrincipal(Center center) {
		Assert.notNull(center);
		Professor professor = professorService.findByPrincipal();
		return subjectRepository.findByCenterIdAndProfessorId(center.getId(),
				professor.getId());
	}

	public Collection<Subject> findAvailableByCenter(Center center) {
		Assert.notNull(center);
		return subjectRepository.findAvailableByCenterId(center.getId(),
				new Date());
	}

	public Collection<Subject> findByPrincipalProfessor() {
		Professor professor = professorService.findByPrincipal();
		return subjectRepository.findByProfessorId(professor.getId());
	}

	public void checkIsPrincipal(Actor a) {
		UserAccount principal = LoginService.getPrincipal();
		Assert.isTrue(principal.equals(a.getUserAccount()));
	}
}
