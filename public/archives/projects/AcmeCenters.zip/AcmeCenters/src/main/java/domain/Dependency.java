package domain;

public enum Dependency {

	PUBLIC, PRIVATE

}
