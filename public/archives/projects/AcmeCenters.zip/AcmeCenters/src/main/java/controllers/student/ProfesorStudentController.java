package controllers.student;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ProfessorService;
import services.StudentService;
import controllers.AbstractController;
import domain.Professor;
import domain.Student;

@Controller
@RequestMapping("/professor/student")
public class ProfesorStudentController extends AbstractController {

	@Autowired
	private ProfessorService professorService;

	@Autowired
	private StudentService studentService;

	@RequestMapping(value = "/listMine", method = RequestMethod.GET)
	public ModelAndView listMine() {
		ModelAndView result;
		Student student = studentService.findByPrincipal();

		Collection<Professor> professors = professorService
				.findProfessorsByStudent(student);

		result = new ModelAndView("professor/list");
		result.addObject("professors", professors);
		result.addObject("requestURI", "professor/student/listMine.do");

		return result;
	}

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam int studentId) {
		ModelAndView result;
		Student s = studentService.findOne(studentId);
		Collection<Professor> professors = professorService
				.findProfessorsByStudent(s);
		Professor p = professorService.findByPrincipal();
		Assert.isTrue(professors.contains(p));

		Student student = studentService.findOne(studentId);
		int id = student.getId();

		String name = student.getName();
		String surname = student.getSurname();
		String address = student.getAddress();
		String phone = student.getPhone();
		String email = student.getEmail();
		String nameAndSurnamesFather = student.getNameAndSurnamesFather();
		String nameAndSurnamesMother = student.getNameAndSurnamesMother();
		String illnessesAndDissabilities = student
				.getIllnessesAndDissabilities();
		String interests = student.getInterests();

		result = new ModelAndView("student/display");
		result.addObject("id", id);

		result.addObject("name", name);
		result.addObject("surname", surname);
		result.addObject("address", address);
		result.addObject("phone", phone);
		result.addObject("email", email);
		result.addObject("nameAndSurnamesFather", nameAndSurnamesFather);
		result.addObject("nameAndSurnamesMother", nameAndSurnamesMother);
		result.addObject("illnessesAndDissabilities", illnessesAndDissabilities);
		result.addObject("interests", interests);
		return result;

	}

}
