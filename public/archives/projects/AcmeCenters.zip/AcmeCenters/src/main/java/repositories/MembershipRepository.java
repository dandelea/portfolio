package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Membership;

@Repository
public interface MembershipRepository extends
		JpaRepository<Membership, Integer> {

	@Query("select b from Membership b where b.professor.id=?1")
	Collection<Membership> findByProfessorId(int professorId);

	@Query("select b from Membership b where b.center.id=?1")
	Collection<Membership> findByCenterId(int centerId);
}
