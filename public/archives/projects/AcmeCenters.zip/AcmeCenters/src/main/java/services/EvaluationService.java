package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import repositories.EvaluationRepository;
import security.LoginService;
import security.UserAccount;
import domain.Actor;
import domain.Evaluation;
import domain.Notification;
import domain.NotificationType;
import domain.Professor;
import domain.Student;
import domain.Subject;

@Service
@Transactional
public class EvaluationService {

	// Managed repository
	@Autowired
	private EvaluationRepository evaluationRepository;

	// Support services
	@Autowired
	private ActorService actorService;

	@Autowired
	private StudentService studentService;

	@Autowired
	private ProfessorService professorService;

	@Autowired
	private EvaluatedStudentService evaluatedStudentService;

	@Autowired
	private SubjectService subjectService;

	@Autowired
	private NotificationService notificationService;

	// CRUD methods

	public Evaluation findOne(int evaluationId) {
		return evaluationRepository.findOne(evaluationId);
	}

	public Evaluation create(Subject subject) {
		Assert.notNull(subject);
		Evaluation evaluation = new Evaluation();
		evaluation.setSubject(subject);
		return evaluation;
	}

	// Business methods
	public Collection<Evaluation> findBySubject(Subject subject) {
		Assert.notNull(subject);
		checkPrincipalBelongsToSubject(subject);
		return evaluationRepository.findBySubjectId(subject.getId());
	}

	public Collection<Evaluation> findNotRegisteredBySubject(Subject subject) {
		Assert.notNull(subject);
		Student student = studentService.findByPrincipal();
		return evaluationRepository.findNotRegisteredBySubjectId(
				subject.getId(), student.getId());
	}

	public Collection<Evaluation> findRegistered() {
		Student student = studentService.findByPrincipal();
		return evaluationRepository.findRegisteredByStudentId(student.getId());
	}

	public Collection<Evaluation> findRegisteredNotFinished() {
		Student student = studentService.findByPrincipal();
		return evaluationRepository.findRegisteredNotFinished(student.getId());
	}

	public Evaluation save(Evaluation evaluation) {
		Assert.notNull(evaluation);
		checkIsPrincipal(evaluation.getSubject().getMembership().getProfessor());
		Assert.isTrue(evaluation.getFinishDate().after(new Date()));
		Assert.isTrue(evaluatedStudentService.findByEvaluation(evaluation)
				.isEmpty());
		Assert.isTrue(evaluation.getSubject().getRegistrationLimit()
				.before(new Date()));
		Evaluation result = evaluationRepository.save(evaluation);

		// Registrar a los estudiantes automaticamente si es obligatoria.
		if (result.getObligatory()) {
			evaluatedStudentService.registerObligatoryEvaluation(result);
		}

		// Notificar del cambio si es una evaluaci�n nueva.
		if (evaluation.getId() == 0) {
			Collection<Student> students = studentService
					.findBySubject(evaluation.getSubject());
			
			//Datos de la notificaci�n: nombre de la evaluaci�n y de su asignatura
			List<String> data = new ArrayList<String>();
			data.add(evaluation.getName());
			data.add(evaluation.getSubject().getName());
			for (Student student : students) {
				Notification notification = notificationService.create(student);
				notification
						.setNotificationType(NotificationType.NEW_EVALUATION);
				notification.setData(data);
				notificationService.save(notification);
			}
		}

		return result;
	}

	public void delete(Evaluation evaluation) {
		Assert.notNull(evaluation);
		checkIsPrincipal(evaluation.getSubject().getMembership().getProfessor());
		Assert.isTrue(evaluatedStudentService.findByEvaluation(evaluation)
				.isEmpty());
		Assert.isTrue(evaluation.getFinishDate().after(new Date()));
		evaluationRepository.delete(evaluation);
	}

	public void checkIsPrincipal(Actor a) {
		UserAccount principal = LoginService.getPrincipal();
		Assert.isTrue(principal.equals(a.getUserAccount()));
	}

	private void checkPrincipalBelongsToSubject(Subject subject) {
		Actor a = actorService.findByPrincipal();
		if (a instanceof Student) {
			Student student = studentService.findByPrincipal();
			Assert.isTrue(subjectService.findByStudent(student).contains(
					subject));
		} else if (a instanceof Professor) {
			Professor professor = professorService.findByPrincipal();
			Assert.isTrue(subject.getMembership().getProfessor()
					.equals(professor));
		}
	}

}
