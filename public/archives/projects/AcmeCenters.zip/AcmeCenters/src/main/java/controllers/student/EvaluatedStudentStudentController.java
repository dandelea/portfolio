package controllers.student;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.EvaluatedStudentService;
import services.StudentService;
import services.SubjectService;
import controllers.AbstractController;
import domain.EvaluatedStudent;
import domain.Student;
import domain.Subject;

@Controller
@RequestMapping("/evaluatedStudent/student")
public class EvaluatedStudentStudentController extends AbstractController {

	// Support services
	@Autowired
	private EvaluatedStudentService evaluatedStudentService;
	@Autowired
	private StudentService studentService;
	@Autowired
	private SubjectService subjectService;

	// Constructor
	public EvaluatedStudentStudentController() {
		super();
	}

	@RequestMapping(value = "/listMine", method = RequestMethod.GET)
	public ModelAndView listMine() {
		ModelAndView result;
		Student student = studentService.findByPrincipal();
		Collection<EvaluatedStudent> evaluatedStudents = evaluatedStudentService
				.findFinishedByStudent(student);
		boolean finished = true;
		String requestURI = "evaluatedStudent/student/listMine.do";
		result = new ModelAndView("evaluatedStudent/list");
		result.addObject("evaluatedStudents", evaluatedStudents);
		result.addObject("finished", finished);
		result.addObject("requestURI", requestURI);
		return result;
	}

	@RequestMapping(value = "/listMineFromSubject", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam int subjectId) {
		ModelAndView result;
		Subject subject = subjectService.findOne(subjectId);
		Collection<EvaluatedStudent> evaluatedStudents = evaluatedStudentService
				.findBySubjectForPrincipalStudent(subject);
		boolean finished = false;
		String requestURI = "evaluatedStudent/student/listMineFromSubject.do?subjectId="
				+ subjectId;
		result = new ModelAndView("evaluatedStudent/list");
		result.addObject("evaluatedStudents", evaluatedStudents);
		result.addObject("finished", finished);
		result.addObject("requestURI", requestURI);
		return result;
	}

}
