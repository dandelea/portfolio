package controllers.professor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.StudentService;
import controllers.AbstractController;
import domain.Student;

@Controller
@RequestMapping("/student/professor")
public class StudentProfessorController extends AbstractController {

	@Autowired
	private StudentService studentService;

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam int studentId) {
		ModelAndView result;

		Student student = studentService.findOne(studentId);
		int id = student.getId();

		String name = student.getName();
		String surname = student.getSurname();
		String address = student.getAddress();
		String phone = student.getPhone();
		String email = student.getEmail();
		String nameAndSurnamesFather = student.getNameAndSurnamesFather();
		String nameAndSurnamesMother = student.getNameAndSurnamesMother();
		String illnessesAndDissabilities = student
				.getIllnessesAndDissabilities();
		String interests = student.getInterests();

		result = new ModelAndView("student/display");
		result.addObject("id", id);

		result.addObject("name", name);
		result.addObject("surname", surname);
		result.addObject("address", address);
		result.addObject("phone", phone);
		result.addObject("email", email);
		result.addObject("nameAndSurnamesFather", nameAndSurnamesFather);
		result.addObject("nameAndSurnamesMother", nameAndSurnamesMother);
		result.addObject("illnessesAndDissabilities", illnessesAndDissabilities);
		result.addObject("interests", interests);
		return result;

	}

}
