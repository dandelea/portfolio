package controllers;

import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import security.LoginService;
import security.UserAccount;
import services.CenterService;
import services.RegistrationService;
import services.SubjectService;
import domain.Center;
import domain.Registration;
import domain.Subject;

@Controller
@RequestMapping("/subject")
public class SubjectController extends AbstractController {

	@Autowired
	private CenterService centerService;

	@Autowired
	private SubjectService subjectService;

	@Autowired
	private RegistrationService registrationService;

	// Constructors -----------------------------------------------------------

	public SubjectController() {
		super();
	}

	@RequestMapping(value = "/listByCenter", method = RequestMethod.GET)
	private ModelAndView listByCenter(@RequestParam int centerId) {
		ModelAndView result;
		Center center = centerService.findOne(centerId);
		Collection<Subject> subjects = subjectService.findByCenter(center);

		result = new ModelAndView("subject/list");
		result.addObject("subjects", subjects);
		result.addObject("requestURI", "subject/listByCenter.do");

		return result;
	}

	@RequestMapping(value = "/listAvailableByCenter", method = RequestMethod.GET)
	private ModelAndView listAvailableByCenter(@RequestParam int centerId) {
		ModelAndView result;
		Center center = centerService.findOne(centerId);
		Collection<Subject> subjects = subjectService
				.findAvailableByCenter(center);

		result = new ModelAndView("subject/list");
		result.addObject("subjects", subjects);
		result.addObject("requestURI", "subject/listByCenter.do");

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam int subjectId) {
		Subject subject = subjectService.findOne(subjectId);
		return createEditModelAndView(subject);
	}

	private ModelAndView createEditModelAndView(Subject subject) {
		ModelAndView result;

		result = createEditModelAndView(subject, null);

		return result;
	}

	private ModelAndView createEditModelAndView(Subject subject, String message) {
		ModelAndView result;
		boolean isStudent = false;
		boolean isAvailable = false;
		boolean isProfessor = false;
		if (subject.getId() > 0) {
			Collection<Registration> registrations = registrationService
					.findBySubject(subject);

			if (subject.getNumberStudents() < subject
					.getMaximumNumberStudents()
					&& subject.getRegistrationLimit().after(new Date())) {
				isAvailable = true;
			}

			// El try-catch evita que no se muestre la p�gina si se hace la
			// comprobaci�n siendo un usuario an�nimo
			try {
				UserAccount principal = LoginService.getPrincipal();

				isProfessor = subject.getMembership().getProfessor()
						.getUserAccount().equals(principal);

				// Si no es profesor, comprueba que es alumno.
				if (!isProfessor) {
					for (Registration registration : registrations) {
						if (registration.getStudent().getUserAccount()
								.equals(principal)) {
							isStudent = true;
						}
					}
				}

			} catch (IllegalArgumentException e) {

			}
		}

		result = new ModelAndView("subject/edit");
		result.addObject("subject", subject);
		result.addObject("isStudent", isStudent);
		result.addObject("isProfessor", isProfessor);
		result.addObject("isAvailable", isAvailable);
		result.addObject("message", message);

		return result;
	}

}
