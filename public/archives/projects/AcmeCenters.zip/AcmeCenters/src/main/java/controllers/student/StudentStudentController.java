package controllers.student;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.StudentService;
import controllers.AbstractController;
import domain.Student;
import forms.StudentEditForm;

@Controller
@RequestMapping("/student/student")
public class StudentStudentController extends AbstractController {

	@Autowired
	private StudentService studentService;

	@RequestMapping(value = "/displayMine", method = RequestMethod.GET)
	public ModelAndView displayMine() {
		ModelAndView result;

		Student student = studentService.findByPrincipal();

		int id = student.getId();

		String name = student.getName();
		String surname = student.getSurname();
		String address = student.getAddress();
		String phone = student.getPhone();
		String email = student.getEmail();
		String nameAndSurnamesFather = student.getNameAndSurnamesFather();
		String nameAndSurnamesMother = student.getNameAndSurnamesMother();
		String illnessesAndDissabilities = student
				.getIllnessesAndDissabilities();
		String interests = student.getInterests();
		Boolean mine = true;
		result = new ModelAndView("student/display");
		result.addObject("id", id);
		result.addObject("mine", mine);
		result.addObject("name", name);
		result.addObject("surname", surname);
		result.addObject("address", address);
		result.addObject("phone", phone);
		result.addObject("email", email);
		result.addObject("nameAndSurnamesFather", nameAndSurnamesFather);
		result.addObject("nameAndSurnamesMother", nameAndSurnamesMother);
		result.addObject("illnessesAndDissabilities", illnessesAndDissabilities);
		result.addObject("interests", interests);
		return result;

	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		StudentEditForm studentEditForm;
		Student s = studentService.findByPrincipal();
		studentEditForm = studentService.edit(s);

		result = createModelAndView(studentEditForm);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid StudentEditForm studentEditForm,
			BindingResult binding) {
		ModelAndView result;
		Student s = studentService.findByPrincipal();

		if (binding.hasErrors()) {
			result = createModelAndView(studentEditForm);
		} else {
			try {
				s = studentService.reconstructEdit(studentEditForm);
				studentService.save(s);
				result = displayMine();
			} catch (Throwable oops) {
				result = createModelAndView(studentEditForm,
						"student.commit.error");
			}
		}
		return result;
	}

	private ModelAndView createModelAndView(StudentEditForm studentEditForm) {
		ModelAndView result;

		result = createModelAndView(studentEditForm, null);

		return result;
	}

	private ModelAndView createModelAndView(StudentEditForm studentEditForm,
			String message) {
		ModelAndView result;

		result = new ModelAndView("student/editMine");
		result.addObject("studentEditForm", studentEditForm);
		result.addObject("message", message);

		return result;
	}

}
