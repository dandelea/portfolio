package domain;

public enum NotificationType {

	NEW_EVALUATION, NEW_MARK, CHANGED_MARK, ACCEPTED_PROPOSAL, DENIED_PROPOSAL

}
