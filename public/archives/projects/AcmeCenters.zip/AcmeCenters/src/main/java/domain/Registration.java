package domain;

import java.util.Collection;
import java.util.HashSet;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Entity
@Access(AccessType.PROPERTY)
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "student_id",
		"subject_id" }))
public class Registration extends DomainEntity {
	private Double finalMark;
	private Student student;
	private Subject subject;
	private Collection<EvaluatedStudent> evaluatedStudents;

	public Registration() {
		super();
		this.evaluatedStudents = new HashSet<EvaluatedStudent>();
	}

	@Min(0)
	public Double getFinalMark() {
		return finalMark;
	}

	public void setFinalMark(Double finalMark) {
		this.finalMark = finalMark;
	}

	// Relations

	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	@NotNull
	@Valid
	@OneToMany(mappedBy = "registration")
	public Collection<EvaluatedStudent> getEvaluatedStudents() {
		return evaluatedStudents;
	}

	public void setEvaluatedStudents(
			Collection<EvaluatedStudent> evaluatedStudents) {
		this.evaluatedStudents = evaluatedStudents;
	}
}
