package services;

import java.util.Collection;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import repositories.MembershipRepository;
import security.LoginService;
import security.UserAccount;
import domain.Actor;
import domain.Membership;
import domain.Center;
import domain.Professor;

@Service
@Transactional
public class MembershipService {

	// Managed repository
	@Autowired
	private MembershipRepository membershipRepository;

	@Autowired
	private ProfessorService professorService;

	public Collection<Membership> findByProfessor(Professor professor) {
		Assert.notNull(professor);
		return membershipRepository.findByProfessorId(professor.getId());
	}

	public Collection<Membership> findByPrincipal() {
		Professor professor = professorService.findByPrincipal();
		return membershipRepository.findByProfessorId(professor.getId());
	}

	public Collection<Membership> findByCenter(Center center) {
		Assert.notNull(center);
		return membershipRepository.findByCenterId(center.getId());
	}

	public Membership create(Center center) {
		Assert.notNull(center);
		Professor professor = professorService.findByPrincipal();
		Membership membership = new Membership();
		membership.setCenter(center);
		membership.setProfessor(professor);
		return membership;
	}

	public Membership save(Membership membership) {
		Assert.notNull(membership);
		checkIsPrincipal(membership.getProfessor());
		return membershipRepository.save(membership);
	}

	public void checkIsPrincipal(Actor a) {
		UserAccount principal = LoginService.getPrincipal();
		Assert.isTrue(principal.equals(a.getUserAccount()));
	}
}
