package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.EvaluatedStudent;

@Repository
public interface EvaluatedStudentRepository extends
		JpaRepository<EvaluatedStudent, Integer> {

	@Query("select e from EvaluatedStudent e where e.evaluation.id=?1")
	public Collection<EvaluatedStudent> findByEvaluationId(int id);

	@Query("select e from EvaluatedStudent e where e.evaluation.finishDate<CURRENT_DATE and e.registration.student.id=?1")
	public Collection<EvaluatedStudent> findFinishedByStudentId(int id);

	@Query("select e from EvaluatedStudent e where e.registration.id=?1")
	public Collection<EvaluatedStudent> findByRegistrationId(int id);

	@Query("select e from EvaluatedStudent e where e.evaluation.subject.id=?1 and e.registration.student.id=?2")
	public Collection<EvaluatedStudent> findBySubjectIdAndStudentId(
			int subjectId, int studentId);

}
