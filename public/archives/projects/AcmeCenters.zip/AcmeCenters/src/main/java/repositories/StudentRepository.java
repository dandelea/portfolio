package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer> {

	@Query("select a from Student a where a.userAccount.id=?1")
	public Student findByUserAccountId(int id);

	@Query("select r.student from Registration r where r.subject.id=?1")
	public Collection<Student> findBySubjectId(int id);

}
