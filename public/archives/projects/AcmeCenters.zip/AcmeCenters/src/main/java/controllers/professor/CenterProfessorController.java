package controllers.professor;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import security.LoginService;
import security.UserAccount;
import services.CenterService;
import services.MembershipService;
import controllers.AbstractController;
import domain.Center;
import domain.Membership;

@Controller
@RequestMapping("/center/professor")
public class CenterProfessorController extends AbstractController {

	@Autowired
	private CenterService centerService;

	@Autowired
	private MembershipService membershipService;

	// Constructors -----------------------------------------------------------

	public CenterProfessorController() {
		super();
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid Center center, BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			result = createEditModelAndView(center);
		} else {
			try {
				centerService.save(center);
				result = new ModelAndView("redirect:../../welcome/index.do");
			} catch (Throwable oops) {
				result = createEditModelAndView(center, "center.commit.error");
			}
		}
		return result;
	}

	@RequestMapping(value = "/listMine", method = RequestMethod.GET)
	public ModelAndView listMine() {
		ModelAndView result;

		Collection<Center> centers = centerService.findByPrincipal();

		result = new ModelAndView("center/list");
		result.addObject("centers", centers);

		return result;
	}

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	private ModelAndView create() {
		Center center = centerService.create();
		return createEditModelAndView(center);
	}

	@RequestMapping(value = "/join", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam int centerId) {
		Center center = centerService.findOne(centerId);
		Membership membership = membershipService.create(center);
		ModelAndView result;
		try {
			membershipService.save(membership);
			result = listMine();
		} catch (Throwable oops) {
			result = createEditModelAndView(center, "center.commit.error");
		}
		return result;
	}

	private ModelAndView createEditModelAndView(Center center) {
		ModelAndView result;

		result = createEditModelAndView(center, null);

		return result;
	}

	private ModelAndView createEditModelAndView(Center center, String message) {
		ModelAndView result;
		boolean isProfessor = false;

		Collection<Membership> memberships = membershipService
				.findByCenter(center);

		if (center.getId() > 0) {
			// El try-catch evita que no se muestre la p�gina si se hace la
			// comprobaci�n siendo un usuario an�nimo
			try {
				UserAccount principal = LoginService.getPrincipal();
				for (Membership membership : memberships) {
					if (membership.getProfessor().getUserAccount()
							.equals(principal)) {
						isProfessor = true;
					}
				}
			} catch (IllegalArgumentException e) {

			}
		}

		result = new ModelAndView("center/edit");
		result.addObject("center", center);
		result.addObject("isProfessor", isProfessor);
		result.addObject("message", message);

		return result;
	}

}
