package forms;

import javax.persistence.Column;
import javax.persistence.Lob;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.web.multipart.MultipartFile;

public class StudentForm {
	private MultipartFile picture;
	private String phone, nameAndSurnamesFather, nameAndSurnamesMother,
			interests, illnessesAndDissabilities;
	private String address, email, name, surnames, username, password,
			password2;
	private boolean accept;

	@Lob
	@Column(columnDefinition = "mediumblob")
	public MultipartFile getPicture() {
		return picture;
	}

	public void setPicture(MultipartFile picture) {
		this.picture = picture;
	}

	@NotNull
	public String getIllnessesAndDissabilities() {
		return illnessesAndDissabilities;
	}

	public void setIllnessesAndDissabilities(String illnessesAndDissabilities) {
		this.illnessesAndDissabilities = illnessesAndDissabilities;
	}

	@NotNull
	@NotBlank
	public String getInterests() {
		return interests;
	}

	public void setInterests(String interests) {
		this.interests = interests;
	}

	@NotNull
	@NotBlank
	public String getNameAndSurnamesMother() {
		return nameAndSurnamesMother;
	}

	public void setNameAndSurnamesMother(String nameAndSurnamesMother) {
		this.nameAndSurnamesMother = nameAndSurnamesMother;
	}

	@NotNull
	@NotBlank
	public String getNameAndSurnamesFather() {
		return nameAndSurnamesFather;
	}

	public void setNameAndSurnamesFather(String nameAndSurnamesFather) {
		this.nameAndSurnamesFather = nameAndSurnamesFather;
	}

	@NotNull
	@NotBlank
	@Pattern(regexp = "\\d{9}")
	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@NotNull
	@NotBlank
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@NotNull
	@NotBlank
	@Email
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@NotNull
	@NotBlank
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@NotNull
	@NotBlank
	public String getSurnames() {
		return surnames;
	}

	public void setSurnames(String surnames) {
		this.surnames = surnames;
	}

	@NotNull
	@NotBlank
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@NotNull
	@NotBlank
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean getAccept() {
		return accept;
	}

	public void setAccept(boolean accept) {
		this.accept = accept;
	}

	@NotNull
	@NotBlank
	public String getPassword2() {
		return password2;
	}

	public void setPassword2(String password2) {
		this.password2 = password2;
	}

}
