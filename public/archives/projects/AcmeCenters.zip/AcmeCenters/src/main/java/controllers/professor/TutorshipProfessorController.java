package controllers.professor;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.SubjectService;
import services.ProfessorService;
import services.TutorshipService;
import controllers.AbstractController;
import domain.Subject;
import domain.Professor;
import domain.Tutorship;

@Controller
@RequestMapping("/tutorship/professor")
public class TutorshipProfessorController extends AbstractController {

	// Support services
	@Autowired
	private TutorshipService tutorshipService;
	@Autowired
	private SubjectService subjectService;
	@Autowired
	private ProfessorService professorService;

	// Constructor
	public TutorshipProfessorController() {
		super();
	}

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam int subjectId) {
		Subject subject = subjectService.findOne(subjectId);
		Tutorship tutorship = tutorshipService.create(subject);
		return createEditModelAndView(tutorship);
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam int tutorshipId) {
		Tutorship tutorship = tutorshipService.findOne(tutorshipId);
		return createEditModelAndView(tutorship);
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid Tutorship tutorship, BindingResult binding) {
		ModelAndView result;
		if (binding.hasErrors()) {
			result = createEditModelAndView(tutorship);
		} else {
			try {
				tutorshipService.save(tutorship);
				result = new ModelAndView(
						"redirect:../../tutorship/list.do?subjectId="
								+ tutorship.getSubject().getId());
			} catch (Throwable oops) {
				result = createEditModelAndView(tutorship,
						"tutorship.commit.error");
			}
		}
		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(@Valid Tutorship tutorship, BindingResult binding) {
		ModelAndView result;

		try {
			tutorshipService.delete(tutorship);
			result = new ModelAndView(
					"redirect:../../tutorship/list.do?subjectId="
							+ tutorship.getSubject().getId());
		} catch (Throwable oops) {
			result = createEditModelAndView(tutorship, "tutorship.commit.error");
		}

		return result;
	}

	public ModelAndView createEditModelAndView(Tutorship tutorship) {
		return createEditModelAndView(tutorship, null);
	}

	public ModelAndView createEditModelAndView(Tutorship tutorship,
			String message) {
		ModelAndView res;
		Professor principal = professorService.findByPrincipal();
		Assert.isTrue(principal.equals(tutorship.getSubject().getMembership()
				.getProfessor()));
		res = new ModelAndView("tutorship/edit");
		res.addObject("tutorship", tutorship);
		res.addObject("message", message);

		return res;
	}

}
