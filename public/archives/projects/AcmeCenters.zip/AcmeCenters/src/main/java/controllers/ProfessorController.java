package controllers;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import security.LoginService;
import services.CenterService;
import services.ProfessorService;
import domain.Center;
import domain.Professor;
import forms.ProfessorForm;
import forms.ProfessorSearchForm;

@Controller
@RequestMapping("/professor")
public class ProfessorController extends AbstractController {

	@Autowired
	private ProfessorService professorService;

	@Autowired
	private CenterService centerService;

	@RequestMapping(value = "/listByCenter", method = RequestMethod.GET)
	public ModelAndView listByItem(@RequestParam int centerId) {
		ModelAndView result;

		Center c = centerService.findOne(centerId);

		Collection<Professor> professors = professorService
				.findProfessorsByCenter(c);

		result = new ModelAndView("professor/list");
		result.addObject("professors", professors);
		result.addObject("requestURI", "professor/listByCenter.do");

		return result;
	}

	// Se debe usar un m�todo get para que funcione el paginado y la ordenaci�n
	// de resultados
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView search(@RequestParam(required = false) String name,
			@RequestParam(required = false) String surnames,
			@RequestParam(required = false) String email,
			@RequestParam(required = false) String curriculum) {

		ModelAndView result;

		// Si no se ha indicado (o se ha indicado parcialmente) la informaci�n a
		// buscar, se muestra la p�gina de b�squeda
		if (name == null || surnames == null || email == null
				|| curriculum == null) {
			result = searchView();
		} else {

			Collection<Professor> professors;
			ProfessorSearchForm professorSearchForm = new ProfessorSearchForm();
			professorSearchForm.setName(name);
			professorSearchForm.setSurnames(surnames);
			professorSearchForm.setEmail(email);
			professorSearchForm.setCurriculum(curriculum);

			try {
				professors = professorService.search(professorSearchForm);
				result = new ModelAndView("professor/list");
				result.addObject("professors", professors);
				result.addObject("requestURI", "professor/search.do");
			} catch (Throwable oops) {
				result = new ModelAndView("professor/search");
				result.addObject("professorSearchForm", professorSearchForm);
				result.addObject("message", "professor.commit.error");
			}
		}

		return result;
	}

	private ModelAndView searchView() {
		ModelAndView result;

		ProfessorSearchForm professorSearchForm = new ProfessorSearchForm();

		result = new ModelAndView("professor/search");
		result.addObject("professorSearchForm", professorSearchForm);

		return result;
	}

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		ProfessorForm professorForm;

		professorForm = new ProfessorForm();

		result = createModelAndView(professorForm);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid ProfessorForm professorForm,
			BindingResult binding) {
		ModelAndView result;
		Professor professor;

		if (binding.hasErrors()) {
			result = createModelAndView(professorForm);
		} else {
			try {
				Assert.isTrue(professorForm.getAccept());
				professor = professorService.reconstruct(professorForm);
				professorService.register(professor);
				result = new ModelAndView("redirect:../welcome/index.do");
			} catch (Throwable oops) {
				result = createModelAndView(professorForm,
						"professor.commit.error");
			}
		}
		return result;
	}

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam int professorId) {
		ModelAndView result;

		Professor professor = professorService.findOne(professorId);
		
		int id = professorId;
		
		String name = professor.getName();
		String surname = professor.getSurname();
		String email = professor.getEmail();
		String curriculum = professor.getCurriculum();
		Boolean canEdit = LoginService.getPrincipal().equals(professor.getUserAccount());
		
		result = new ModelAndView("professor/display");
		result.addObject("id", id);

		result.addObject("name", name);
		result.addObject("surname", surname);
		result.addObject("email", email);
		result.addObject("curriculum", curriculum);
		result.addObject("canEdit", canEdit);
		return result;

	}

	@RequestMapping(value = "/picture", method = RequestMethod.GET)
	public void picture(@RequestParam int professorId, HttpServletResponse res) {

		Professor professor = professorService.findOne(professorId);

		res.setContentType("image/jpeg");

		byte[] picture = professor.getPicture();

		InputStream in1 = new ByteArrayInputStream(picture);

		try {
			IOUtils.copy(in1, res.getOutputStream());

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private ModelAndView createModelAndView(ProfessorForm professorForm) {
		ModelAndView result;

		result = createModelAndView(professorForm, null);

		return result;
	}

	private ModelAndView createModelAndView(ProfessorForm professorForm,
			String message) {
		ModelAndView result;

		result = new ModelAndView("professor/edit");
		result.addObject("professorForm", professorForm);
		result.addObject("message", message);

		return result;
	}
}
