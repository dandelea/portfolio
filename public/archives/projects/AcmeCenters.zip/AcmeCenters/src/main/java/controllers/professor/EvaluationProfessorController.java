package controllers.professor;

import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.EvaluatedStudentService;
import services.EvaluationService;
import services.ProfessorService;
import services.SubjectService;
import controllers.AbstractController;
import domain.Evaluation;
import domain.Subject;

@Controller
@RequestMapping("/evaluation/professor")
public class EvaluationProfessorController extends AbstractController {

	// Support services
	@Autowired
	private EvaluationService evaluationService;

	@Autowired
	private SubjectService subjectService;

	@Autowired
	private ProfessorService professorService;

	@Autowired
	private EvaluatedStudentService evaluatedStudentService;

	// Constructor
	public EvaluationProfessorController() {
		super();
	}

	// List methods

	// Creation

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam int subjectId) {
		Subject subject = subjectService.findOne(subjectId);
		Evaluation evaluation;

		evaluation = evaluationService.create(subject);

		return createEditModelAndView(evaluation);
	}

	// Edition

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid Evaluation evaluation, BindingResult binding) {
		ModelAndView res;
		if (binding.hasErrors()) {
			res = createEditModelAndView(evaluation);
		} else {
			try {
				evaluationService.save(evaluation);
				res = new ModelAndView(
						"redirect:../../evaluation/listFromSubject.do?subjectId="
								+ evaluation.getSubject().getId());
			} catch (Throwable oops) {
				res = createEditModelAndView(evaluation,
						"evaluation.commit.error");
			}
		}
		return res;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(@Valid Evaluation evaluation,
			BindingResult binding) {
		ModelAndView result;

		try {
			evaluationService.delete(evaluation);
			result = new ModelAndView(
					"redirect:../../evaluation/professor/listFromSubject.do?subjectId="
							+ evaluation.getSubject().getId());
		} catch (Throwable oops) {
			result = createEditModelAndView(evaluation,
					"evaluation.commit.error");
		}

		return result;
	}

	public ModelAndView createEditModelAndView(Evaluation evaluation) {
		return createEditModelAndView(evaluation, null);
	}

	public ModelAndView createEditModelAndView(Evaluation evaluation,
			String message) {
		Assert.notNull(evaluation);
		ModelAndView result;
		boolean finished = false;
		boolean isProfessor = false;
		boolean participating = false;
		boolean nobodyRegistered = evaluatedStudentService.findByEvaluation(
				evaluation).isEmpty();
		// No est� creandose
		if (evaluation.getId() != 0) {
			Date today = new Date();
			finished = today.after(evaluation.getFinishDate());
		}
		isProfessor = evaluation.getSubject().getMembership().getProfessor()
				.equals(professorService.findByPrincipal());

		result = new ModelAndView("evaluation/display");
		result.addObject("evaluation", evaluation);
		result.addObject("finished", finished);
		result.addObject("isProfessor", isProfessor);
		result.addObject("nobodyRegistered", nobodyRegistered);
		result.addObject("participating", participating);
		result.addObject("message", message);

		return result;
	}

}
