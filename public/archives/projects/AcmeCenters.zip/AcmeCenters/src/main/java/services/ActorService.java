package services;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import repositories.ActorRepository;
import security.LoginService;
import security.UserAccount;
import domain.Actor;

@Service
@Transactional
public class ActorService {

	// Managed repository
	@Autowired
	private ActorRepository actorRepository;

	// Constructor

	public ActorService() {
		super();
	}

	// CRUD methods

	public Actor findOne(int id) {
		return actorRepository.findOne(id);
	}

	// Business methods

	public Actor findByUserAccount(UserAccount userAccount) {
		return actorRepository.findByUserAccountId(userAccount.getId());
	}

	public Actor findByPrincipal() {
		UserAccount principal = LoginService.getPrincipal();
		return findByUserAccount(principal);
	}

	public void checkPrincipal(Actor a) {
		UserAccount actual = LoginService.getPrincipal();
		Assert.isTrue(a.getUserAccount().equals(actual));
	}

}
