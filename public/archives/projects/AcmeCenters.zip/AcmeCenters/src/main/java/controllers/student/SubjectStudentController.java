package controllers.student;

import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import security.LoginService;
import security.UserAccount;
import services.RegistrationService;
import services.SubjectService;
import controllers.AbstractController;
import domain.Registration;
import domain.Subject;

@Controller
@RequestMapping("/subject/student")
public class SubjectStudentController extends AbstractController {

	@Autowired
	private SubjectService subjectService;

	@Autowired
	private RegistrationService registrationService;

	// Constructors -----------------------------------------------------------

	public SubjectStudentController() {
		super();
	}

	@RequestMapping(value = "/join", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam int subjectId) {
		Subject subject = subjectService.findOne(subjectId);
		Registration registration = registrationService.create(subject);
		ModelAndView result;
		try {
			registrationService.save(registration);
			result = new ModelAndView(
					"redirect:../../registration/student/listMine.do");
		} catch (Throwable oops) {
			result = createEditModelAndView(subject, "subject.commit.error");
		}
		return result;
	}

	private ModelAndView createEditModelAndView(Subject subject, String message) {
		ModelAndView result;
		boolean isStudent = false;
		boolean isAvailable = false;
		boolean isProfessor = false;
		if (subject.getId() > 0) {
			Collection<Registration> registrations = registrationService
					.findBySubject(subject);

			if (subject.getNumberStudents() < subject
					.getMaximumNumberStudents()
					&& subject.getRegistrationLimit().after(new Date())) {
				isAvailable = true;
			}

			// El try-catch evita que no se muestre la p�gina si se hace la
			// comprobaci�n siendo un usuario an�nimo
			try {
				UserAccount principal = LoginService.getPrincipal();
				for (Registration registration : registrations) {
					if (registration.getStudent().getUserAccount()
							.equals(principal)) {
						isStudent = true;
					}
				}

				if (subject.getMembership().getProfessor().getUserAccount()
						.equals(principal)) {
					isProfessor = true;
				}
			} catch (IllegalArgumentException e) {

			}
		}

		result = new ModelAndView("subject/edit");
		result.addObject("subject", subject);
		result.addObject("isStudent", isStudent);
		result.addObject("isProfessor", isProfessor);
		result.addObject("isAvailable", isAvailable);
		result.addObject("message", message);

		return result;
	}

}
