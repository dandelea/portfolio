package domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;

@Entity
@Access(AccessType.PROPERTY)
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "registration_id",
		"evaluation_id" }))
public class EvaluatedStudent extends DomainEntity {
	private Double mark;
	private Registration registration;
	private Evaluation evaluation;

	public EvaluatedStudent() {
		super();
	}

	@Range(min = 0, max = 10)
	public Double getMark() {
		return mark;
	}

	public void setMark(Double mark) {
		this.mark = mark;
	}

	// Relations

	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Registration getRegistration() {
		return registration;
	}

	public void setRegistration(Registration registration) {
		this.registration = registration;
	}

	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Evaluation getEvaluation() {
		return evaluation;
	}

	public void setEvaluation(Evaluation evaluation) {
		this.evaluation = evaluation;
	}

}
