package services;

import java.util.Collection;
import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import repositories.NotificationRepository;
import security.LoginService;
import security.UserAccount;
import domain.Actor;
import domain.Notification;
import domain.Student;

@Service
@Transactional
public class NotificationService {

	// Managed repository
	@Autowired
	private NotificationRepository notificationRepository;

	public Notification findOne(int notificationId) {
		return notificationRepository.findOne(notificationId);
	}

	public Collection<Notification> findByStudent(Student student) {
		Assert.notNull(student);
		checkPrincipal(student);
		return notificationRepository.findByStudentId(student.getId());
	}

	public Notification create(Student student) {
		Assert.notNull(student);
		Notification n = new Notification();
		n.setStudent(student);
		Date date = new Date(System.currentTimeMillis() - 1000);
		n.setCreationDate(date);
		return n;
	}

	public Notification save(Notification n) {
		Assert.notNull(n);
		Assert.isTrue(n.getId() == 0);
		Notification result = notificationRepository.save(n);
		return result;
	}

	public void checkPrincipal(Actor a) {
		UserAccount actual = LoginService.getPrincipal();
		Assert.isTrue(a.getUserAccount().equals(actual));
	}
}
