package domain;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
@Table(indexes = { @Index(columnList = "finishDate") })
public class Evaluation extends DomainEntity {
	private String name, description, deliverablesDescription;
	private double weighting;
	private Date finishDate;
	private Subject subject;
	private Collection<EvaluatedStudent> evaluatedStudents;
	private boolean obligatory;

	public Evaluation() {
		super();
		this.evaluatedStudents = new HashSet<EvaluatedStudent>();
	}

	@NotNull
	@NotBlank
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@NotNull
	@NotBlank
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@NotNull
	public String getDeliverablesDescription() {
		return deliverablesDescription;
	}

	public void setDeliverablesDescription(String deliverablesDescription) {
		this.deliverablesDescription = deliverablesDescription;
	}

	@Range(min = 0, max = 1)
	public double getWeighting() {
		return weighting;
	}

	public void setWeighting(double weighting) {
		this.weighting = weighting;
	}

	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "dd/MM/yyyy HH:mm")
	public Date getFinishDate() {
		return finishDate;
	}

	public void setFinishDate(Date finishDate) {
		this.finishDate = finishDate;
	}

	// Relations

	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	@NotNull
	@Valid
	@OneToMany(mappedBy = "evaluation")
	public Collection<EvaluatedStudent> getEvaluatedStudents() {
		return evaluatedStudents;
	}

	public void setEvaluatedStudents(
			Collection<EvaluatedStudent> evaluatedStudents) {
		this.evaluatedStudents = evaluatedStudents;
	}

	public boolean getObligatory() {
		return obligatory;
	}

	public void setObligatory(boolean obligatory) {
		this.obligatory = obligatory;
	}
}
