package domain;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
@Table(indexes = { @Index(columnList = "numberStudents"),
		@Index(columnList = "maximumNumberStudents") })
public class Subject extends DomainEntity {
	private String name;
	private int grade;
	private Date registrationLimit;
	private int numberStudents;
	private int maximumNumberStudents;
	private Membership membership;
	private Collection<Tutorship> tutorships;
	private Collection<Proposal> proposals;
	private Collection<Registration> registrations;
	private Collection<Evaluation> evaluations;

	public Subject() {
		super();
		this.tutorships = new HashSet<Tutorship>();
		this.proposals = new HashSet<Proposal>();
		this.registrations = new HashSet<Registration>();
		this.evaluations = new HashSet<Evaluation>();
	}

	@NotNull
	@NotBlank
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Range(min = 1, max = 20)
	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "dd/MM/yyyy HH:mm")
	public Date getRegistrationLimit() {
		return registrationLimit;
	}

	public void setRegistrationLimit(Date registrationLimit) {
		this.registrationLimit = registrationLimit;
	}

	@Min(0)
	public int getNumberStudents() {
		return numberStudents;
	}

	public void setNumberStudents(int numberStudents) {
		this.numberStudents = numberStudents;
	}

	@Min(1)
	public int getMaximumNumberStudents() {
		return maximumNumberStudents;
	}

	public void setMaximumNumberStudents(int maximumNumberStudents) {
		this.maximumNumberStudents = maximumNumberStudents;
	}

	// Relations

	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Membership getMembership() {
		return membership;
	}

	public void setMembership(Membership membership) {
		this.membership = membership;
	}

	@NotNull
	@Valid
	@OneToMany(mappedBy = "subject")
	public Collection<Tutorship> getTutorships() {
		return tutorships;
	}

	public void setTutorships(Collection<Tutorship> tutorships) {
		this.tutorships = tutorships;
	}

	@NotNull
	@Valid
	@OneToMany(mappedBy = "subject")
	public Collection<Proposal> getProposals() {
		return proposals;
	}

	public void setProposals(Collection<Proposal> proposals) {
		this.proposals = proposals;
	}

	@NotNull
	@Valid
	@OneToMany(mappedBy = "subject")
	public Collection<Registration> getRegistrations() {
		return registrations;
	}

	public void setRegistrations(Collection<Registration> registrations) {
		this.registrations = registrations;
	}

	@NotNull
	@Valid
	@OneToMany(mappedBy = "subject")
	public Collection<Evaluation> getEvaluations() {
		return evaluations;
	}

	public void setEvaluations(Collection<Evaluation> evaluations) {
		this.evaluations = evaluations;
	}

}
