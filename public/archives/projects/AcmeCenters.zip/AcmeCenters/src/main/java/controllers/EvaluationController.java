package controllers;

import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import security.Authority;
import security.LoginService;
import services.EvaluatedStudentService;
import services.EvaluationService;
import services.ProfessorService;
import services.SubjectService;
import domain.Evaluation;
import domain.Subject;

@Controller
@RequestMapping("/evaluation")
public class EvaluationController extends AbstractController {

	// Support services
	@Autowired
	private EvaluationService evaluationService;
	@Autowired
	private SubjectService subjectService;
	@Autowired
	private ProfessorService professorService;
	@Autowired
	private EvaluatedStudentService evaluatedStudentService;

	// Constructor
	public EvaluationController() {
		super();
	}

	// List

	@RequestMapping(value = "/listFromSubject", method = RequestMethod.GET)
	public ModelAndView listFromSubject(@RequestParam int subjectId) {
		ModelAndView result;
		Subject subject = subjectService.findOne(subjectId);
		Collection<Evaluation> evaluations;
		String requestURI;

		evaluations = evaluationService.findBySubject(subject);
		requestURI = "evaluation/listFromSubject.do?subjectId=" + subjectId;
		boolean isAvailable = subject.getRegistrationLimit().before(new Date());

		result = new ModelAndView("evaluation/list");
		result.addObject("evaluations", evaluations);
		result.addObject("subject", subject);
		result.addObject("requestURI", requestURI);
		result.addObject("isAvailable", isAvailable);

		return result;
	}

	// Display

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam int evaluationId) {
		ModelAndView result;
		Evaluation evaluation = evaluationService.findOne(evaluationId);
		Date today = new Date();
		boolean finished = today.after(evaluation.getFinishDate());
		Authority auth = new Authority();
		auth.setAuthority("PROFESSOR");
		boolean isProfessor = false;
		boolean nobodyRegistered = evaluatedStudentService.findByEvaluation(
				evaluation).isEmpty();
		if (LoginService.getPrincipal().getAuthorities().contains(auth)) {
			isProfessor = evaluation.getSubject().getMembership()
					.getProfessor().equals(professorService.findByPrincipal());
		}
		boolean participating = false;
		auth.setAuthority("STUDENT");
		if (LoginService.getPrincipal().getAuthorities().contains(auth)) {
			participating = evaluationService.findRegistered().contains(
					evaluation);
		}

		result = new ModelAndView("evaluation/display");
		result.addObject("evaluation", evaluation);
		result.addObject("finished", finished);
		result.addObject("isProfessor", isProfessor);
		result.addObject("nobodyRegistered", nobodyRegistered);
		result.addObject("participating", participating);

		return result;
	}
}
