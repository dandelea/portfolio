package controllers.professor;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.ProfessorService;
import controllers.AbstractController;
import domain.Professor;
import forms.ProfessorEditForm;

@Controller
@RequestMapping("/professor/professor")
public class ProfessorProfessorController extends AbstractController {

	@Autowired
	private ProfessorService professorService;

	@RequestMapping(value = "/displayMine", method = RequestMethod.GET)
	public ModelAndView displayMine() {
		ModelAndView result;

		Professor professor = professorService.findByPrincipal();

		int id = professor.getId();
		String name = professor.getName();
		String surname = professor.getSurname();
		String email = professor.getEmail();
		String curriculum = professor.getCurriculum();
		Boolean mine = true;
		result = new ModelAndView("professor/display");
		result.addObject("id", id);
		result.addObject("mine", mine);
		result.addObject("name", name);
		result.addObject("surname", surname);
		result.addObject("email", email);
		result.addObject("curriculum", curriculum);
		result.addObject("canEdit", true);
		return result;

	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView create() {
		ModelAndView result;
		ProfessorEditForm professorEditForm;
		Professor s = professorService.findByPrincipal();
		professorEditForm = professorService.edit(s);

		result = createModelAndView(professorEditForm);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid ProfessorEditForm professorEditForm,
			BindingResult binding) {
		ModelAndView result;
		Professor s = professorService.findByPrincipal();

		if (binding.hasErrors()) {
			result = createModelAndView(professorEditForm);
		} else {
			try {
				s = professorService.reconstructEdit(professorEditForm);
				professorService.save(s);
				result = displayMine();
			} catch (Throwable oops) {
				result = createModelAndView(professorEditForm,
						"professor.commit.error");
			}
		}
		return result;
	}

	private ModelAndView createModelAndView(ProfessorEditForm professorEditForm) {
		ModelAndView result;

		result = createModelAndView(professorEditForm, null);

		return result;
	}

	private ModelAndView createModelAndView(
			ProfessorEditForm professorEditForm, String message) {
		ModelAndView result;

		result = new ModelAndView("professor/editMine");
		result.addObject("professorEditForm", professorEditForm);
		result.addObject("message", message);

		return result;
	}

}
