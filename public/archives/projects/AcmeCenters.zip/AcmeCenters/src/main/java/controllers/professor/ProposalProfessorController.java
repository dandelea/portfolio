package controllers.professor;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ProposalService;
import controllers.AbstractController;
import domain.Proposal;

@Controller
@RequestMapping("/proposal/professor")
public class ProposalProfessorController extends AbstractController {

	// Support services
	@Autowired
	private ProposalService proposalService;

	// Constructor
	public ProposalProfessorController() {
		super(); 
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<Proposal> proposals = proposalService
				.findByPrincipalProfessorNotFinished();
		String requestURI = "proposal/professor/list.do";
		result = new ModelAndView("proposal/list");
		result.addObject("proposals", proposals);
		result.addObject("requestURI", requestURI);
		return result;
	}

	@RequestMapping(value = "/accept", method = RequestMethod.GET)
	public ModelAndView accept(@RequestParam int proposalId) {
		ModelAndView result;
		Proposal proposal = proposalService.findOne(proposalId);
		result = list();
		try {
			proposalService.accept(proposal);
		} catch (Throwable oops) {
			result.addObject("message", "proposal.commit.error");
		}

		return result;
	}

	@RequestMapping(value = "/decline", method = RequestMethod.GET)
	public ModelAndView decline(@RequestParam int proposalId) {
		ModelAndView result;
		Proposal proposal = proposalService.findOne(proposalId);
		result = list();
		try {
			proposalService.decline(proposal);
		} catch (Throwable oops) {
			result.addObject("message", "proposal.commit.error");
		}

		return result;
	}

}
