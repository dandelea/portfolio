package services;

import java.util.Collection;
import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import repositories.RegistrationRepository;
import security.LoginService;
import security.UserAccount;
import domain.Actor;
import domain.Registration;
import domain.Student;
import domain.Subject;

@Service
@Transactional
public class RegistrationService {

	// Managed repository
	@Autowired
	private RegistrationRepository registrationRepository;

	// Support services
	@Autowired
	private StudentService studentService;
	@Autowired
	private SubjectService subjectService;

	// Business methods
	public Registration findBySubjectForPrincipal(Subject subject) {
		Assert.notNull(subject);
		Student student = studentService.findByPrincipal();
		return registrationRepository.findByStudentIdSubjectId(student.getId(),
				subject.getId());
	}

	public Collection<Registration> findBySubject(Subject subject) {
		Assert.notNull(subject);
		return registrationRepository.findBySubjectId(subject.getId());
	}

	public Collection<Registration> findByPrincipal() {
		Student student = studentService.findByPrincipal();
		return registrationRepository.findByStudentId(student.getId());
	}

	public Registration create(Subject subject) {
		Assert.notNull(subject);
		Student student = studentService.findByPrincipal();
		Registration registration = new Registration();
		registration.setSubject(subject);
		registration.setStudent(student);
		return registration;
	}

	public Registration save(Registration registration) {
		Assert.notNull(registration);
		checkIsPrincipal(registration.getStudent());
		Assert.isTrue(registration.getSubject().getNumberStudents() < registration
				.getSubject().getMaximumNumberStudents());
		Assert.isTrue(registration.getSubject().getRegistrationLimit()
				.after(new Date()));
		subjectService.addStudent(registration.getSubject());
		return registrationRepository.save(registration);
	}

	public Registration updateFinalMarks(Registration registration) {
		Assert.notNull(registration);
		Double finalMark = registrationRepository
				.calculateFinalMark(registration.getId());
		registration.setFinalMark(finalMark);
		return registrationRepository.save(registration);
	}

	public void checkIsPrincipal(Actor a) {
		UserAccount principal = LoginService.getPrincipal();
		Assert.isTrue(principal.equals(a.getUserAccount()));
	}
}
