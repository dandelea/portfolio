package controllers.student;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.ProposalService;
import services.TutorshipService;
import controllers.AbstractController;
import domain.Proposal;
import domain.Subject;
import domain.Tutorship;

@Controller
@RequestMapping("/proposal/student")
public class ProposalStudentController extends AbstractController {

	// Support services
	@Autowired
	private ProposalService proposalService;
	@Autowired
	private TutorshipService tutorshipService;

	// Constructor
	public ProposalStudentController() {
		super();
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView res;
		Collection<Proposal> proposals = proposalService
				.findByPrincipalStudentNotFinished();
		String requestURI = "proposal/student/list.do";
		res = new ModelAndView("proposal/list");
		res.addObject("proposals", proposals);
		res.addObject("requestURI", requestURI);

		return res;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid Proposal proposal, BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors()) {
			result = createEditModelAndView(proposal);
		} else {
			try {
				proposalService.save(proposal);
				result = list();
			} catch (Throwable oops) {
				result = createEditModelAndView(proposal,
						"proposal.commit.error");
			}
		}
		return result;
	}

	public ModelAndView createEditModelAndView(Proposal proposal) {
		return createEditModelAndView(proposal, null);
	}

	public ModelAndView createEditModelAndView(Proposal proposal, String message) {
		Collection<Tutorship> tutorships = tutorshipService
				.findBySubject(proposal.getSubject());
		Subject subject = proposal.getSubject();

		ModelAndView res = new ModelAndView("tutorship/list");
		res.addObject("proposal", proposal);
		res.addObject("tutorships", tutorships);
		res.addObject("subject", subject);
		res.addObject("message", message);

		return res;

	}
}
