package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Notification;

@Repository
public interface NotificationRepository extends
		JpaRepository<Notification, Integer> {

	@Query("select n from Notification n where n.student.id=?1 order by creationDate desc")
	public Collection<Notification> findByStudentId(int id);

}
