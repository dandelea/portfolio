package controllers.student;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import controllers.AbstractController;

import services.NotificationService;
import services.StudentService;
import domain.Notification;
import domain.Student;

@Controller
@RequestMapping("/notification/student")
public class NotificationStudentController extends AbstractController {

	public NotificationStudentController() {
		super();
	}

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private StudentService studentService;

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Student student = studentService.findByPrincipal();
		Collection<Notification> notifications = notificationService
				.findByStudent(student);

		result = new ModelAndView("notification/list");
		result.addObject("notifications", notifications);
		result.addObject("requestURI", "notification/student/list.do");

		return result;
	}

}
