var map;
var markers;
var schools = [];
function init() {
	var fromProjection = new OpenLayers.Projection("EPSG:4326");   // Transform from WGS 1984
	var toProjection   = new OpenLayers.Projection("EPSG:900913"); // to Spherical Mercator Projection
	var positions = [];

	for (var i = 0; i<schools.length; i++) {
		positions.push(new OpenLayers.LonLat(schools[i].lng, schools[i].lat).transform(fromProjection, toProjection));
	}
	map = new OpenLayers.Map("map");
	var mapnik = new OpenLayers.Layer.OSM();
	map.addLayer(mapnik);
	
	markers = new OpenLayers.Layer.Markers( "markers" );
	map.addLayer(markers);
	map.setCenter(positions[0], 11);
	for (var i = 0; i<positions.length; i++) {
		addMarker(positions[i], OpenLayers.Popup.AutoSizeAnchored, messageName+": "+schools[i].name+"<br/><a href='"+schools[i].url+"'>"+messageDetails+"</a>", true);
	}
}

function addMarker(ll, popupClass, popupContentHTML, closeBox, overflow) {

    var feature = new OpenLayers.Feature(markers, ll); 
    feature.closeBox = closeBox;
    feature.popupClass = popupClass;
    feature.data.popupContentHTML = popupContentHTML;
    feature.data.overflow = (overflow) ? "auto" : "hidden";
            
    var marker = feature.createMarker();

    var markerClick = function (evt) {
        if (this.popup == null) {
            this.popup = this.createPopup(this.closeBox);
            map.addPopup(this.popup);
            this.popup.show();
        } else {
            this.popup.toggle();
        }
        currentPopup = this.popup;
        OpenLayers.Event.stop(evt);
    };
    marker.events.register("mousedown", feature, markerClick);

    markers.addMarker(marker);
}