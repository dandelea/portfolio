var map;
var markers;
var toProjection = new OpenLayers.Projection("EPSG:4326");   // Transform to WGS 1984
var fromProjection   = new OpenLayers.Projection("EPSG:900913"); // from Spherical Mercator Projection
function initLocationSelector(){

	map = new OpenLayers.Map("map");
	
	var mapnik = new OpenLayers.Layer.OSM();
	map.addLayer(mapnik);
	markers = new OpenLayers.Layer.Markers( "markers" );
	map.addLayer(markers);
	map.setCenter((new OpenLayers.LonLat(-4.911, 37.484)).transform(toProjection, fromProjection), 7);
	
	map.events.register('click', map, handleMapClick);
}

function handleMapClick(evt)
{
   var lonlat = map.getLonLatFromViewPortPx(evt.xy).transform(fromProjection, toProjection);
   $("#longitude").val(lonlat.lon);
   $("#location\\.longitude").val(lonlat.lon);
   $("#latitude").val(lonlat.lat);
   $("#location\\.latitude").val(lonlat.lat);
   markers.clearMarkers();
   var feature = new OpenLayers.Feature(markers, lonlat.transform(toProjection, fromProjection)); 
   marker = feature.createMarker();
   markers.addMarker(marker);

} 
